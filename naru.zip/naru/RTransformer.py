import random
import time
import sys
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

import scipy.stats

import ProgressivePart

MASK_SCHEME = 1

# constants

DEFAULT_DIM_HEAD = 16
MIN_DIM_HEAD = 8
# class EncodeInput(nn.Module):
#     def __init__(self):
#         super().__init__()
#
#     def forward(self, x):


class BlockRecurrentDecoder(nn.Module):

    def __init__(self, num_tokens,
                 d_model,
                 nin,
                 input_bins,
                 use_positional_embs=True,
                 fixed_ordering=None,
                 seed=0,
                 block=1,
                 isresidual=True
                 # use_memory_cuda=True
    ):
        super().__init__()

        self.nin = nin
        encoded_bins = [d_model] * nin
        self.input_bins = input_bins
        self.d_model = d_model
        self.embed_size = d_model
        self.use_positional_embs = use_positional_embs
        self.column_masking = True
        self.fixed_ordering = fixed_ordering
        if fixed_ordering is None:
            natural = np.arange(nin)
            if seed is None or seed==0:
                self.fixed_ordering = natural
            else:
                self.fixed_ordering = np.random.RandomState(seed).permutation(
                    natural)

        print('ordering', self.fixed_ordering)
        if MASK_SCHEME==1:
            self.xmask = order_respecting_mask(nin, self.fixed_ordering)
            # self.statemask = order_respecting_mask(nin, self.fixed_ordering)
        print(self.xmask)

        if self.column_masking:
            self.unk_embeddings = nn.ParameterList()
            for i, dist_size in enumerate(self.input_bins):
                self.unk_embeddings.append(nn.Parameter(torch.zeros(d_model)))

        self.embeddings = nn.ModuleList()
        for i in range(nin):
            self.embeddings.append(nn.Embedding(self.input_bins[i], d_model))
        for e in self.embeddings:
            nn.init.normal_(e.weight, std=0.02)

        if use_positional_embs:
            self.pos_embeddings = nn.Embedding(self.nin + 1, d_model)
            nn.init.normal_(self.pos_embeddings.weight, std=0.01)

        self.attn = BlockRecurrentAttention(self.d_model, self.d_model,isresidual=isresidual)
        self.norm = nn.LayerNorm(self.d_model)
        self.stateNorm = nn.LayerNorm(self.d_model)

        self.input_bins_encoded_cumsum = np.cumsum(encoded_bins)
        self.orderings = [self.fixed_ordering]
    def forward(self, x, state=None):
        # [bs, ncols]
        x = self.EncodeInput(x)
        # [bs, ncols+1, d_model]
        x, state = self.attn(x, state, mask=self.xmask.to(x.device))

        x = self.norm(x)
        state = self.stateNorm(state)
        return x, state

    def EncodeInput(self, x):
        # 这里因为对值进行了离散化，所以必须是整数，这里做个预处理
        device = x.device
        if x.dtype != torch.long:
            x = x.long()
        bs = x.size()[0]

        tmp = torch.zeros(bs, self.embed_size, device=x.device)
        y_embed = []
        y_embed.append(tmp)
        for nat_idx in range(self.nin):
            s = x[:, nat_idx]
            t = self.embeddings[nat_idx](s)

            y_embed.append(t)
            # print(y_embed)


        inp = torch.stack(y_embed, 1)
        inp_seq_len = inp.shape[1]

        if self.column_masking:
            tmp = torch.ones(bs, inp_seq_len, 1, device=device)

            dropout_vec = torch.dropout(tmp,
                                        p=np.random.randint(0,self.nin)/self.nin,
                                        train=self.training)
            batch_mask = torch.clamp(dropout_vec, 0, 1)
            dropped_repr = torch.stack(tuple(self.unk_embeddings)).unsqueeze(0) # 同self.nin一样
            shaped = torch.zeros_like(dropped_repr[:, 0:1, :])
            dropped_repr = torch.cat(
                (shaped, dropped_repr),
                dim=1) # 加了一个

            inp = batch_mask * inp + (1. - batch_mask) * dropped_repr
        # 在transformer rcnn的attention中有相关配置
        # pos_embs = self.pos_embeddings(torch.arange(inp_seq_len, device=x.device)).unsqueeze(0)
        # inp += pos_embs
        return inp

    # TODO 这里计划试试多个col综合起来看，这样可以更符合实际？ 两三个弄在一块这样进行
    def nll(self, logits, data):

        if data.dtype != torch.long:
            data = data.long()
        nll = torch.zeros(logits.size()[0], device=logits.device)
        # x = []
        for i in range(self.nin):
            logits_i = self.logits_for_col(i, logits)
            ce = F.cross_entropy(logits_i, data[:, i], reduction='none')

            nll += ce
        # print(x)
        return nll

    def nll2(self, logits, data):
        if data.dtype != torch.long:
            data = data.long()
        # nll
        pass

    def logits_for_col(self, idx, logits):
        """Returns the logits (vector) corresponding to log p(x_i | x_(<i)).

        Args:
          idx: int, in natural (table) ordering.
          logits: [batch size, ncols+1, d_model].

        Returns:
          logits_for_col: [batch size, domain size for column idx].
        """
        embed = self.embeddings[idx]
        # s = logits[:, idx, :]
        # q = embed.weight.t()
        return torch.matmul(logits[:, idx, :], embed.weight.t())




    def EncodeInputInference(self, x, natural_col, out):
        """Special inference path.

        Args:
          x: [batch size, 1].  Just the data for column 'natural_col'.
          natural_col (int): [0, num cols).
          out: shaped [batch size, d_model].  To hold the encoded data.
        """
        if natural_col < 0:
            # Potentially handling SOS.
            if self.use_positional_embs:
                # Let's also add E_pos=0 to SOS (if enabled).
                out.copy_(
                    self.pos_embeddings(torch.as_tensor(
                        0,
                        device=x.device)).unsqueeze(0).expand(x.size()[0], -1))
            return

        if x is None:
            # [bs, d_model]
            embs = self.unk_embeddings[natural_col].unsqueeze(0).expand(
                out.shape[0], -1)
        else:
            # [bs, d_model]
            embs = self.embeddings[natural_col](x).squeeze(1)

        if self.use_positional_embs:
            # NOTE: this is tricky.  Under MASK_SCHEME=0 or 1, E_pos=0 is added
            # to SOS, E_pos=1 is added to x0, etc.  So we need to take this into
            # account.
            pos = self.pos_embeddings(
                torch.as_tensor(natural_col + 1,
                                device=out.device)).unsqueeze(0)
            embs = embs + pos

        out.copy_(embs)


    def name(self):
        n = 'RTransformer'
        n += 'xMask'
        n += '-model' + str(self.d_model)
        # n += '-heads' + str(self.num_heads)
        if self.use_positional_embs:
            n += '-posEmb'
        if self.column_masking:
            n += '-colmask'
        if MASK_SCHEME == 1:
            n += '-scheme1'
        return n


    def forward_with_encoded_input(self, x):
        # [batch size, num cols * d_model] -> [bs, num cols, d_model]
        x = x.view(x.shape[0], -1, self.d_model)

        if MASK_SCHEME == 1:

            # 这里换成forward中的encodeinput以下部分就可以了
            # x = self.in_transposelinear(x)
            # embed 用不着，故而先删除
            # x = self.embed(x)
            x, _ = self.attn(x, mask=self.xmask.to(x.device))
            # for b in self.net:
            #     x, _ = b(x, None, mask=self.xmask.to(x.device))
                # x = self.norm(x)
            x = self.norm(x)
                # state = self.stateNorm(state)
            # x = self.to_logits(x)
            # x = self.out_transposelinear(x)
            return x


from typing import Optional, Union
def entropy_vec(pk,
            qk = None,
            base: Optional[float] = None,
            axis: int = 0
            ) -> Union[np.number, np.ndarray]:

    if base is not None and base <= 0:
        raise ValueError("`base` must be a positive number or `None`.")

    pk = np.asarray(pk)
    pk = 1.0 * pk / np.sum(pk, axis=axis, keepdims=True)
    if qk is None:
        vec = scipy.special.entr(pk)
    else:
        qk = np.asarray(qk)
        pk, qk = np.broadcast_arrays(pk, qk)
        qk = 1.0 * qk / np.sum(qk, axis=axis, keepdims=True)
        vec = scipy.special.rel_entr(pk, qk)
    if base is not None:
        vec /= np.log(base)
    return vec
    # S = np.sum(vec, axis=axis)
    # if base is not None:
    #     S /= np.log(base)
    # return S

class RecurrentStateGate(nn.Module):
    """Poor man's LSTM
    """
    def __init__(self, dim: int):
        super().__init__()
        # TODO 这里考虑采用一维卷积来降低计算量。
        #  因为这里的linear没有涉及到维度变化，所以可以单独的改改？
        #  全连接和一维卷积理论上是可以相互替代的，而且计算量少很多
        #  先把bias给弄了？
        self.main_proj = nn.Linear(dim, dim, bias=False)
        self.input_proj = nn.Linear(dim, dim, bias=False)
        self.forget_proj = nn.Linear(dim, dim, bias=False)
    # 这里删除了参数限定
    def forward(self, x, state):
        u = self.main_proj(x)
        v = self.input_proj(x) - 1
        w = self.forget_proj(x) + 1
        z = torch.tanh(u)
        i = torch.sigmoid(v)
        f = torch.sigmoid(w)
        return torch.mul(state, f) + torch.mul(z, i)

# 功能中给删了，用不着
class TransposeLinear(nn.Module):
    def __init__(self,
                 nin,
                 nout):
        super(TransposeLinear, self).__init__()
        self.nin = nin
        self.nout = nout
        self.linear = nn.Linear(self.nin, self.nout, bias=False)
    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.linear(x)
        x = x.transpose(1, 2)
        return x

from einops import rearrange, repeat
from torch import einsum

class RotaryEmbedding(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim
        inv_freq = 1. / (10000 ** (torch.arange(0, dim, 2).float() / dim))
        # pytorch一般情况下，是将网络中的参数保存成orderedDict形式的，这里的参数其实包含两种，一
        # 种是模型中各种module含的参数，即nn.Parameter,我们当然可以在网络中定义其他的nn.Parameter参数，
        # 另一种就是buffer,前者每次optim.step会得到更新，而不会更新后者。
        self.register_buffer('inv_freq', inv_freq)

    def forward(self, max_seq_len, *, device, offset=0):
        seq = torch.arange(max_seq_len, device=device) + offset
        # type_as --按照给定的tensor的类型转换类型
        ss = seq.type_as(self.inv_freq)
        freqs = einsum('i , j -> i j', seq.type_as(self.inv_freq), self.inv_freq) # 可能有问题
        emb = torch.cat((freqs, freqs), dim=-1)
        # del freqs, seq
        return rearrange(emb, 'n d -> 1 1 n d')

class TokenEmbedding(nn.Module):
    def __init__(self, nin, dim):
        super.__init__()
        self.dim = dim
        self.nin = nin
        # 将数据从self.nin 转成 self.dim
        self.linear = nn.Linear(self.nin, self.dim)

    def forward(self, x):
        return self.linear(x)

from x_transformers.x_transformers import (
    apply_rotary_pos_emb, default, exists, FeedForward, RMSNorm
)

def cast_tuple(val, num=1):
    return val if isinstance(val, tuple) else ((val,) * num)

# @typechecked
class Attention(nn.Module):
    """Shamelessly copied from github.com/lucidrains/RETRO-pytorch
    """

    def __init__(
            self,
            dim,
            *,
            dim_head=8,
            heads=16,
            causal=False,
            dropout=0.,
            null_kv=False
    ):
        super().__init__()
        self.dim = dim
        self.heads = heads
        self.scale = dim_head ** -0.5
        self.causal = causal

        self.d_state = self.dim // self.heads
        inner_dim = dim_head * heads
        # TODO 改成layerNormal
        self.norm = nn.LayerNorm(dim)
        # 没啥作用
        # self.dropout = nn.Dropout(dropout)

        self.to_q = nn.Linear(dim, inner_dim, bias=False)
        self.to_kv = nn.Linear(dim, inner_dim * 2, bias=False)
        self.to_out = nn.Linear(inner_dim, dim)

        # allowing for attending to nothing (null function)
        # and to save attention from breaking if all retrieved chunks are padded out
        self.null_kv = nn.Parameter(torch.randn(2, inner_dim)) if null_kv else None

    def forward(self, x, mask=None, context=None, pos_emb=None): #Attention
        b, device, h, scale = x.shape[0], x.device, self.heads, self.scale

        x = self.norm(x)
        if context is not None:
            kv_input = context
        else:
            kv_input = x

        q = self.to_q(x)
        k, v = self.to_kv(kv_input).chunk(2, dim=-1)

        # split heads
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h=h), (q, k, v))

        # scale ===这里就是根号下 dk，
        q = q * scale

        # apply relative positional encoding (rotary embeddings)
        if exists(pos_emb):
            q_pos_emb, k_pos_emb = cast_tuple(pos_emb, num=2)
            q = apply_rotary_pos_emb(q, q_pos_emb)
            k = apply_rotary_pos_emb(k, k_pos_emb)

        # add null key / values
        if exists(self.null_kv):
            nk, nv = self.null_kv.unbind(dim=0)
            nk, nv = map(lambda t: repeat(t, '(h d) -> b h 1 d', b=b, h=h), (nk, nv))
            k = torch.cat((nk, k), dim=-2)
            v = torch.cat((nv, v), dim=-2)

        # derive query key similarities
        sim = einsum('b h i d, b h j d -> b h i j', q, k)

        # masking
        mask_value = -torch.finfo(sim.dtype).max

        if exists(mask):
            if exists(self.null_kv):
                mask = F.pad(mask, (1, 0), value=True)

            # mask.to(device)
            mask.to(sim.dtype)
            sim = sim * mask -(1 - mask)*1e10
            # mask = rearrange(mask, 'b j -> b 1 1 j')
            # sim = sim.masked_fill(~mask, mask_value)

        if self.causal:
            i, j = sim.shape[-2:]
            causal_mask = torch.ones(i, j, device=device, dtype=torch.bool).triu(j - i + 1)
            sim = sim.masked_fill(causal_mask, mask_value)
        # attention

        attn = sim.softmax(dim=-1)
        # attn = self.dropout(attn)

        # aggregate
        out = einsum('b h i j, b h j d -> b h i d', attn, v)
        # del attn, v
        # print(id(attn))
        # del attn
        # merge heads
        out = rearrange(out, 'b h n d -> b n (h d)')

        # combine heads linear out
        out2 = self.to_out(out)

        return out2


class BlockRecurrentAttention(nn.Module):
    def   __init__(self,
                 dim:int,
                 dim_state:int,
                 dim_head:int = DEFAULT_DIM_HEAD,
                 state_len:int = 64,
                 heads:int = 16,
                 isresidual=True):
        super().__init__()
        self.scale = dim_head ** -0.5

        attn_kwargs = {}
        self.isresidual = isresidual
        self.dim = dim
        self.dim_state = dim_state

        self.heads = heads
        self.causal = True
        self.state_len = state_len
        rotary_emb_dim = max(dim_head // 2, MIN_DIM_HEAD)
        self.rotary_pos_emb = RotaryEmbedding(rotary_emb_dim)

        self.input_self_attn = Attention(dim, heads=heads, causal=True, **attn_kwargs)
        self.state_self_attn = Attention(dim_state, heads=heads, causal=False, **attn_kwargs)

        self.input_state_cross_attn = Attention(dim, heads=heads, causal=False, **attn_kwargs)
        self.state_input_cross_attn = Attention(dim_state, heads=heads, causal=False, **attn_kwargs)

        self.proj_gate = RecurrentStateGate(dim)
        self.ff_gate = RecurrentStateGate(dim)

        self.input_proj = nn.Linear(dim + dim_state, dim)
        self.state_proj = nn.Linear(dim + dim_state, dim)

        self.input_ff = FeedForward(dim)
        self.state_ff = FeedForward(dim_state)

        # self.state_norm = nn.LayerNorm(dim_state)
        # self.input_norm = nn.LayerNorm(dim)

        # self.transposelinear = TransposeLinear()

    # @typechecked
    def forward(self, x, state=None, mask=None, state_mask=None):
        batch, seq_len, device = x.shape[0], x.shape[-2], x.device
        state_len = seq_len
        if not exists(state):
            state = torch.zeros([batch, state_len, self.dim_state], device=device)

        self_attn_pos_emb = self.rotary_pos_emb(seq_len, device=device)
        state_pos_emb = self.rotary_pos_emb(seq_len, device=device)

        state_attn = self.state_self_attn(state, mask=state_mask, pos_emb=state_pos_emb)
        input_attn = self.input_self_attn(x, mask=mask, pos_emb=self_attn_pos_emb)
        state_as_q_cross_attn = self.state_input_cross_attn(state, context=x, mask=state_mask)
        input_as_q_cross_attn = self.input_state_cross_attn(x, context=state, mask=mask)

        projected_input = self.input_proj(torch.concat((input_as_q_cross_attn, input_attn), dim=2))

        projected_state = self.state_proj(torch.concat((state_as_q_cross_attn, state_attn), dim=2))

        if self.isresidual:
            input_residual = projected_input + x
        else:
            input_residual = projected_input

        state_residual = self.proj_gate(projected_state, state)
        # input_residual = self.input_norm(input_residual)
        # state_residual = self.state_norm(state_residual)
        # input_residual = input_residual.to(device)
        if self.isresidual:
            output = self.input_ff(input_residual) + input_residual
        else:
            output = self.input_ff(input_residual)
        next_state = self.ff_gate(self.state_ff(state_residual), state_residual)
        return output, next_state

def mask(n):
    ns = n
    nd = n
    i = torch.arange(nd)[:, None]
    j = torch.arange(ns)
    m = i >= j - ns + nd
    m.requires_grad = False
    return m


def order_respecting_mask(ncols, ordering, input_layer=True):
    """Construct appropriate mask for attention.

    Assuming o=(2,0,1):
     - set inputs = [ SOS=0,          x0,    x1,     x2 ]
     - so outputs = [ h(x0|x2), h(x1|x0,x2), h(x2), EOS ]

    No one connects to EOS.  SOS connects to everyone.

    Desired mask (row=destination):
        [[1, 0, 0, 1],
         [1, 1, 0, 1],
         [1, 0, 0, 0],
         [0, 0, 0, 0]]

    Mask after the first attention + see self (diagonal)
    Basically == shift above to the left 1 column, then fill diagonal
     - inputs  = [ h(x0|x2), h(x1|x0,x2), h(x2), EOS ]
     - outputs = [ h(x0|x2), h(x1|x0,x2), h(x2), EOS ]
        [[1, 0, 1, 0],
         [1, 1, 1, 0],
         [0, 0, 1, 0],
         [0, 0, 0, 0]]
    """
    mask = np.zeros((ncols + 1, ncols + 1))

    if input_layer:
        mask[:, 0] = 1  # First column is SOS -- everyone can see.
        mask[-1, :] = 0  # No one connects to EOS.
        for pos_src in range(ncols):
            src_nat_idx = ordering[pos_src]
            for pos_dst in range(pos_src + 1, ncols):
                # Variable at pos_dst should see pos_src.
                dst_nat_idx = ordering[pos_dst]
                mask[dst_nat_idx, src_nat_idx + 1] = 1
    else:
        for pos_src in range(ncols):
            src_nat_idx = ordering[pos_src]
            for pos_dst in range(pos_src, ncols):
                dst_nat_idx = ordering[pos_dst]
                mask[dst_nat_idx, src_nat_idx] = 1

    mask = torch.as_tensor(mask, dtype=torch.float32)
    mask.requires_grad = False
    return mask


class LayerNorm(nn.Module):
    """Norm to 0-mean 1-std , then do a learned diagonal affine transform."""

    def __init__(self, features, eps=1e-5):
        super(LayerNorm, self).__init__()
        self.scale = nn.Parameter(torch.ones(features))
        self.shift = nn.Parameter(torch.zeros(features))
        self.eps = eps

    def forward(self, x):
        mean = x.mean(-1, keepdim=True)
        s = (x - mean).pow(2).mean(-1, keepdim=True)
        x = (x - mean) * torch.rsqrt(s + self.eps)
        return self.scale * x + self.shift


class Conv1d(nn.Module):
    """Linear with bias add.  Weights ~ N(std), bias ~ 0."""

    def __init__(self, d_in, d_out, w_init_std=0.02):
        super(Conv1d, self).__init__()

        self.w = nn.Parameter(torch.zeros(d_in, d_out))
        self.b = nn.Parameter(torch.zeros(d_out))
        nn.init.normal_(self.w, std=w_init_std)
        nn.init.zeros_(self.b)
        self.d_in = d_in
        self.d_out = d_out

    def forward(self, x):
        *start, d_in = x.size()
        ous = x.view(-1, d_in)
        out = torch.matmul(x.view(-1, d_in), self.w) + self.b
        out = out.view(start + [self.d_out])
        return out


class MultiHeadSelfAttention(nn.Module):
    """Multi-head self-attention layer.

    Args:
      d_model: last dim of input and output of this module.
      num_heads: number of parallel heads.

    Internally, queries, keys, and values are all produced from the input
    (hence "self"), and all of them are (d_model/num_heads)-dimensional.
    """

    def __init__(self, d_model, num_heads):
        super(MultiHeadSelfAttention, self).__init__()

        assert d_model % num_heads == 0
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_state = d_model // num_heads

        self.qkv_linear = Conv1d(d_model, self.d_state * 3 * num_heads)
        self.linear = Conv1d(num_heads * self.d_state, d_model)

        self.attn_mask = None  # Will be set by caller.

    def _split_heads(self, x):
        # Each input has shape [bs, num cols, d_state * num_heads].
        *start, m = x.size()
        x = x.view(start + [self.num_heads, m // self.num_heads])
        return x.permute(0, 2, 1, 3)

    def _do_attention(self, query, key, value, mask):
        """Accepts Q,K,V each shaped [bs, num heads, num cols, d_state].

        Returns transformed [bs, num_heads, num cols, d_state].
        """
        d_k = query.size()[-1]
        scores = torch.matmul(query, key.transpose(-1, -2)) / np.sqrt(d_k)
        mask = mask.to(scores.dtype)
        scores = scores * mask - (1 - mask) * 1e10
        attn_weights = F.softmax(scores, dim=-1)

        out = torch.matmul(attn_weights, value)
        return out

    def forward(self, x, query_input=None):
        """x: [bs, num cols, d_model].  Output has the same shape."""
        assert x.dim() == 3, x.size()
        bs, ncols, _ = x.size()

        # [bs, num cols, d_state * 3 * num_heads]
        qkv = self.qkv_linear(x)
        # [bs, num heads, num cols, d_state] each
        qs, ks, vs = map(self._split_heads, torch.chunk(qkv, 3, dim=-1))

        if query_input is not None:
            # TODO: obviously can avoid redundant calc.
            qkv = self.qkv_linear(query_input)
            qs, _, _ = map(self._split_heads, torch.chunk(qkv, 3, dim=-1))

        # [bs, num heads, num cols, d_state]
        x = self._do_attention(qs, ks, vs, mask=self.attn_mask.to(x.device))

        # [bs, num cols, num heads, d_state]
        x = x.transpose(1, 2)
        # Concat all heads' outputs: [bs, num cols, num heads * d_state]
        x = x.contiguous().view(bs, ncols, -1)
        # Then do a transform: [bs, num cols, d_model].
        x = self.linear(x)
        return x


class GeLU(nn.Module):

    def __init__(self):
        super().__init__()

    def forward(self, x):
        return 0.5 * x * (1 + torch.tanh(
            np.sqrt(2 / np.pi) * (x + 0.044715 * torch.pow(x, 3))))


# def ReportModel(model, blacklist=None):
#     ps = []
#     for name, p in model.named_parameters():
#         if blacklist is None or blacklist not in name:
#             ps.append(np.prod(p.size()))
#     num_params = sum(ps)
#     mb = num_params * 4 / 1024 / 1024
#     print('Number of model parameters: {} (~= {:.1f}MB)'.format(num_params, mb))
#
#     return mb
import os
import pandas as pd
def LoadOracleCardialitiesTest():
    ORACLE_CARD_FILES = {
        'dmv': 'datasets/cardTest1.csv'
    }
    path = ORACLE_CARD_FILES.get('dmv', None)
    if path and os.path.exists(path):
        df = pd.read_csv(path)
        # assert len(df) == 2000, len(df)
        return df.values.reshape(-1)
    return None
class QLoss():
    def __init__(self, model,
                 table):
        super(QLoss, self).__init__()
        assert isinstance(model, BlockRecurrentDecoder)
        self.est = ProgressivePart.ProgressiveSampling(model=model,
                                                  table=table,
                                                  r=1000,
                                                  device='cuda',
                                                  shortcircuit=True)
        self.table = table
        self.oracle_cards=LoadOracleCardialitiesTest()
        self.cardsl=[]
        self.prenll=None
        self.prequery=None
        self.precard=None
        self.cardnum=0
        # self.oracle_est =
    def nll2(self, oracle_est, iter, numquery=1,rng = np.random.RandomState(8888)):
        nll = torch.tensor(0.0,requires_grad=True)
        # self.oracle_cards
        for i in range(numquery):
            query = GenerateQuery(self.table.columns, rng, self.table)
            cols, ops, vals = query
            truecard = oracle_est.Query(cols, ops,
                            vals) if self.oracle_cards is None else self.oracle_cards[iter*5 +i]
            self.cardsl.append(truecard)
            card = self.est.Query(cols, ops, vals)
            nll += torch.tensor(ErrorMetric(truecard, card))
        return nll

    def nll3(self, oracle_est, numquery=1,rng = np.random.RandomState(8888)):
        # nll = torch.tensor(0.0,requires_grad=True)
        # self.oracle_cards
        if self.prenll is not None :
            if self.prenll.item() <=0.2:
                for i in range(numquery):
                    self.cardnum += 1
                    query = GenerateQuery(self.table.columns, rng, self.table)
                    cols, ops, vals = query
                    truecard = torch.tensor(oracle_est.Query(cols, ops,
                                    vals) if self.oracle_cards is None
                                            else self.oracle_cards[self.cardnum])
                    # self.cardsl.append(truecard)
                    card = torch.tensor(self.est.Query(cols, ops, vals))
                    self.prequery = query
                    self.precard = truecard
                    nll = torch.tensor(ErrorMetric(truecard, card), requires_grad=True).to('cuda')
                    self.prenll = nll

            else:
                cols,ops, vals = self.prequery
                card = torch.tensor(self.est.Query(cols, ops, vals))
                nll = torch.tensor(ErrorMetric(self.precard, card), requires_grad=True).to('cuda')
                self.prenll = nll
        else:
            for i in range(numquery):
                query = GenerateQuery(self.table.columns, rng, self.table)
                cols, ops, vals = query
                truecard = torch.tensor(oracle_est.Query(cols, ops,
                                            vals) if self.oracle_cards is None else
                                        self.oracle_cards[self.cardnum])
                # self.cardsl.append(truecard)
                card = torch.tensor(self.est.Query(cols, ops, vals))
                self.prequery = query
                self.precard = truecard
                nll = torch.tensor(ErrorMetric(truecard, card),requires_grad=True).to('cuda')
                self.prenll = nll

        return nll
    def forward(self, oracle_est, iter):
        loss = self.nll3(oracle_est=oracle_est)

        return loss

def GenerateQuery(all_cols, rng, table, return_col_idx=False):
    """Generate a random query."""
    num_filters = rng.randint(5, 12)
    cols, ops, vals = SampleTupleThenRandom(all_cols=all_cols,
                                            num_filters=num_filters,
                                            rng=rng,
                                            table=table,
                                            args=None,
                                            return_col_idx=return_col_idx)
    return cols, ops, vals

def SampleTupleThenRandom(all_cols,
                          num_filters,
                          rng,
                          table,
                          args,
                          return_col_idx=False):
    s = table.data.iloc[rng.randint(0, table.cardinality)]
    vals = s.values

    # if args.dataset in ['dmv', 'dmv-tiny']:
        # Giant hack for DMV.
    vals[6] = vals[6].to_datetime64()

    idxs = rng.choice(len(all_cols), replace=False, size=num_filters)
    cols = np.take(all_cols, idxs)

    # If dom size >= 10, okay to place a range filter.
    # Otherwise, low domain size columns should be queried with equality.
    # if args.equals == 0:
    ops = rng.choice(['<=', '>=', '='], size=num_filters)
    # elif args.equals == 1:
    #     ops = rng.choice(['='], size=num_filters)
    ops_all_eqs = ['='] * num_filters
    sensible_to_do_range = [c.DistributionSize() >= 10 for c in cols]
    ops = np.where(sensible_to_do_range, ops, ops_all_eqs)

    if num_filters == len(all_cols):
        if return_col_idx:
            return np.arange(len(all_cols)), ops, vals
        return all_cols, ops, vals

    vals = vals[idxs]
    if return_col_idx:
        return idxs, ops, vals

    return cols, ops, vals

def ErrorMetric(est_card, card):
    if card == 0 and est_card != 0:
        return est_card - 1.0
    if card != 0 and est_card == 0:
        return card - 1.0
    if card == 0 and est_card == 0:
        return 1.0 - 1.0
    return max(est_card / card, card / est_card) - 1.0
if __name__ == '__main__':

    # attn = BlockRecurrentAttention(128, 128).to('cuda')

    attn1 = BlockRecurrentDecoder(num_tokens=128,
                                               d_model=128,
                                               nin=11,
                                               input_bins=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]).to('cuda')

    print(attn1)
    a1s = torch.ones([2, 2])
    attention = Attention(dim=64, heads=8, causal=False)
    x = torch.rand([1024, 12, 128]).to('cuda')
    y = torch.rand([1024, 11]).to('cuda')
    # import sys
    state = None
    prestate = torch.zeros([1024, 12, 128])
    statelist = []
    import util.numOp.numDivide as nde

    for i in range(10000):
        if not len(statelist)==0:
            len = len(statelist)
            reli = nde.allocation_amount(len, 0.1)
            for lit,j in statelist, reli:
                prestate = j*lit + prestate
            state = 0.9*state +prestate
        x, state = attn1(y, state)
        # qqqq = sys.getsizeof(state.storage())
        randomnum = random.uniform(0, 100)
        if randomnum<=1:
            print(randomnum)
            statelist.append(state.copy_())

    # w = attention(x)
    y