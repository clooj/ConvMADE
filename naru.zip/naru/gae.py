import torch.nn as nn
import torch.nn.functional as F

import torch
import numpy as np
from torch_geometric.datasets import Planetoid
import torch_geometric.transforms as T
from torch_geometric.nn import GCNConv
from torch_geometric.nn import GAE
from torch_geometric.utils import train_test_split_edges
# 构建图卷积层

OPS = {
    '>': np.greater,
    '<': np.less,
    '>=': np.greater_equal,
    '<=': np.less_equal,
    '=': np.equal,
    '!=': np.not_equal
}







