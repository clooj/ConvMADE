"""Model training."""
import argparse
import copy
import os
import random
import time

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

import RTSimple
import Rmade
import common
import datasets
import estimators
import made as made
import madeplus
import transformer
import RTransformer

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
print('Devicetra', DEVICE)
torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark = True

parser = argparse.ArgumentParser()

# Training.
parser.add_argument('--dataset', type=str, default='dmv', help='Dataset.')
parser.add_argument('--num-gpus', type=int, default=1, help='#gpus.')
parser.add_argument('--bs', type=int, default=1024, help='Batch size.')
parser.add_argument('--warmups', type=int, default=20000, help='Learning rate warmup steps.  Crucial for Transformer.')
parser.add_argument('--epochs',
                    type=int,
                    default=20,
                    help='Number of epochs to train for.')
parser.add_argument('--constant-lr',
                    type=float,
                    default=None,
                    help='Constant LR?')
parser.add_argument(
    '--column-masking',
    action='store_true',
    help='Column masking training, which permits wildcard skipping'\
    ' at querying time.')

#Conv
parser.add_argument('--conv', action='store_true')
parser.add_argument('--shuffle', action='store_true')
parser.add_argument('--convgroup', type=int, default=32)
parser.add_argument('--channels', type=int, default=96)
parser.add_argument('--convblocknum', type=int, default=1)
parser.add_argument('--kernelsize', type=int, default=9)

# MADE.
parser.add_argument('--fc-hiddens',
                    type=int,
                    default=128,
                    help='Hidden units in FC.')
parser.add_argument('--layers', type=int, default=4, help='# layers in FC.')
parser.add_argument('--residual', action='store_true', help='ResMade?')
parser.add_argument('--direct-io', action='store_true', help='Do direct IO?')
parser.add_argument(
    '--inv-order',
    action='store_true',
    help='Set this flag iff using MADE and specifying --order. Flag --order '\
    'lists natural indices, e.g., [0 2 1] means variable 2 appears second.'\
    'MADE, however, is implemented to take in an argument the inverse '\
    'semantics (element i indicates the position of variable i).  Transformer'\
    ' does not have this issue and thus should not have this flag on.')
parser.add_argument(
    '--input-encoding',
    type=str,
    default='binary',
    help='Input encoding for MADE/ResMADE, {binary, one_hot, embed}.')
parser.add_argument(
    '--output-encoding',
    type=str,
    default='binary',
    help='Iutput encoding for MADE/ResMADE, {one_hot, embed}.  If embed, '
    'then input encoding should be set to embed as well.')

# Transformer.
parser.add_argument(
    '--heads',
    type=int,
    default=0,
    help='Transformer: num heads.  A non-zero value turns on Transformer'\
    ' (otherwise MADE/ResMADE).'
)
parser.add_argument('--blocks',
                    type=int,
                    default=2,
                    help='Transformer: num blocks.')
parser.add_argument('--dmodel',
                    type=int,
                    default=32,
                    help='Transformer: d_model.')
parser.add_argument('--dff', type=int, default=128, help='Transformer: d_ff.')
parser.add_argument('--transformer-act',
                    type=str,
                    default='gelu',
                    help='Transformer activation.')

# RT
parser.add_argument('--rt', action='store_true')
parser.add_argument('--numtokens', type=int, default=64)
parser.add_argument('--residualrt', action='store_false')
# parser.add_argument('--numtokens', type=int, default=64)
# Ordering.
parser.add_argument('--num-orderings',
                    type=int,
                    default=1,
                    help='Number of orderings.')
parser.add_argument(
    '--order',
    nargs='+',
    type=int,
    required=False,
    help=
    'Use a specific ordering.  '\
    'Format: e.g., [0 2 1] means variable 2 appears second.'
)

args = parser.parse_args()


def Entropy(name, data, bases=None):
    import scipy.stats
    s = 'Entropy of {}:'.format(name)
    ret = []
    for base in bases:
        assert base == 2 or base == 'e' or base is None
        e = scipy.stats.entropy(data, base=base if base != 'e' else None) # 计算给定概率值的分布熵。
        ret.append(e)
        unit = 'nats' if (base == 'e' or base is None) else 'bits'
        s += ' {:.4f} {}'.format(e, unit)
    print(s)
    return ret

def Entropys(data, bases=None):
    import scipy.stats
    ret = []
    for base in bases:
        assert base == 2 or base == 'e' or base is None
        e = scipy.stats.entropy(data, base=base if base != 'e' else None) # 计算给定概率值的分布熵。
        ret.append(e)
    return ret

def RunEpoch(split,
             model,
             opt,
             table,
             schedu=None,
             train_data=None,
             test_data=None,
             val_data=None,
             batch_size=100,
             upto=None,
             epoch_num=None,
             verbose=False,
             log_every=10,
             return_losses=False,
             table_bits=None):
    torch.set_grad_enabled(split == 'train')
    model.train() if split == 'train' else model.eval()

    dataset = train_data if split == 'train' else test_data

    losses = []
    val_losses = []

    if split == 'train':
        train_loader = torch.utils.data.DataLoader(train_data,
                                                   batch_size=batch_size,
                                                   shuffle=True)
        loader = train_loader
        # valdataset = val_data
        # val_loader = torch.utils.data.DataLoader(valdataset,
        #                                          batch_size=batch_size,
        #                                          shuffle=False)
    else:
        test_loader = torch.utils.data.DataLoader(test_data,
                                                  batch_size=batch_size,
                                                  shuffle=False)
        loader = test_loader

    # How many orderings to run for the same batch?
    model = model.to('cuda')
    state = None
    nsamples = 1
    if hasattr(model, 'orderings'):
        nsamples = len(model.orderings)

    # oracle_est = estimators.Oracle(table)
    # if isinstance(model, transformer.Transformer):
    #     qloss = transformer.QLoss(model, table)
    # if isinstance(model, RTransformer.BlockRecurrentDecoder):
    #     qloss = RTransformer.QLoss(model, table)

    for step, xb in enumerate(loader):
        if isinstance(model, Rmade.MADE) and args.output_encoding=="binary":
            data = xb

            data = data.long()

            # for j in range(2000):
            nlldata = []
            for i in range(len(table.columns)):
                s = data[:, i]
                q =[table.columns[i].all_distinct_values_bincode[x] for x in s.tolist()]
                k = torch.stack(q)
                nlldata.append(k)
            nlldata = torch.cat(nlldata, dim=1).to(DEVICE)

            # nlldata2 = model.ToBinaryAsOneHot(data.to(DEVICE))

        if split == 'train':
            base_lr = 8e-4
            for param_group in opt.param_groups:
                if args.constant_lr:
                    lr = args.constant_lr
                elif args.warmups:
                    t = args.warmups
                    d_model = model.embed_size
                    global_steps = len(loader) * epoch_num + step + 1
                    lr = (d_model**-0.5) * min(
                        (global_steps**-.5), global_steps * (t**-1.5))
                else:
                    lr = 1e-2

                # 这里的lr直接把opt里面的param_gourps中值给改了。
                param_group['lr'] = lr

        if upto and step >= upto:
            break

        xb = xb.to(DEVICE).to(torch.float32)

        # Forward pass, potentially through several orderings.
        xbhat = None
        if isinstance(model, RTransformer.BlockRecurrentDecoder):
            xbstate = None
        model_logits = []
        num_orders_to_forward = 1
        if split == 'test' and nsamples > 1:
            # At test, we want to test the 'true' nll under all orderings.
            num_orders_to_forward = nsamples

        for i in range(num_orders_to_forward):
            # if hasattr(model, 'update_masks'):
            #     # We want to update_masks even for first ever batch.
            #     model.update_masks()
            if not isinstance(model, RTransformer.BlockRecurrentDecoder) and not isinstance(model, RTSimple.BlockRecurrentDecoder):
                model_out = model(xb)
            else:

                batch = xb.shape[0]
                if not batch<batch_size:


                    model_out, state = model(xb, state)
                    state = state.data

                    # x = ran
                else:
                    # state = state[0: batch]
                    model_out, _ = model(xb)
            model_logits.append(model_out)
            if xbhat is None:
                # 输入为矩阵x
                # 输出为形状和x一致的矩阵，其元素全部为0
                xbhat = torch.zeros_like(model_out)
            if isinstance(model, RTransformer.BlockRecurrentDecoder):
                if xbstate is None:
                    xbstate = torch.zeros_like(state)
                if not batch < batch_size:
                    xbstate = xbstate + state
                    state = xbstate.data
            # 这里之前是加起来，估计是为了获得全局感受野，
            xbhat += model_out
            # xbhat = model_out

        # 可能之前的二进制没给搞好
        if xbhat.shape == xb.shape:
            # if mean:
            #     xb = (xb * std) + mean
        # 这里也是有问题，直接给判断了，从linux系统角度来看，这里应该是没有跑，难道之前归一化过？
            loss = F.binary_cross_entropy_with_logits(
                xbhat, xb, size_average=False) / xbhat.size()[0]
        else:
            if model.input_bins is None:
                # NOTE: we have to view() it in this order due to the mask
                # construction within MADE.  The masks there on the output unit
                # determine which unit sees what input vars.
                xbhat = xbhat.view(-1, model.nout // model.nin, model.nin)
                # Equivalent to:
                loss = F.cross_entropy(xbhat, xb.long(), reduction='none') \
                        .sum(-1).mean()
            else:
                if num_orders_to_forward == 1:
                    # loss = model.nll(xbhat, xb).mean()
                    # 暂时先试试
                    if isinstance(model, transformer.Transformer) or isinstance(model, RTransformer.BlockRecurrentDecoder):
                        loss = model.nll(xbhat, xb).mean()
                        # stateloss = model.nll(state, xb).mean()
                        # if model.useqloss:
                        # if True:
                        #     loss1 = qloss.nll3(oracle_est)
                        #     loss =loss+ 0.0005 * loss1 + stateloss
                    else:
                        if isinstance(model, Rmade.MADE) and args.output_encoding=='binary':
                            loss = model.nllP(xbhat, nlldata).mean()
                        else:
                            loss = model.nll(xbhat, xb).mean()
                else:
                    # Average across orderings & then across minibatch.
                    #
                    #   p(x) = 1/N sum_i p_i(x)
                    #   log(p(x)) = log(1/N) + log(sum_i p_i(x))
                    #             = log(1/N) + logsumexp ( log p_i(x) )
                    #             = log(1/N) + logsumexp ( - nll_i (x) )
                    #
                    # Used only at test time.
                    logps = []  # [batch size, num orders]
                    assert len(model_logits) == num_orders_to_forward, len(
                        model_logits)
                    for logits in model_logits:
                        # Note the minus.
                        logps.append(-model.nll(logits, xb))
                    logps = torch.stack(logps, dim=1)
                    logps = logps.logsumexp(dim=1) + torch.log(
                        torch.tensor(1.0 / nsamples, device=logps.device))
                    loss = (-logps).mean()
        # TODO 暂时先注释掉
        losses.append(loss.item())

        if step % log_every == 0:
            if split == 'train':
                # lr = opt.state_dict()['param_groups'][0]['lr']
                strins = 'Epoch '+ str(epoch_num)
                strins = strins + ' Iter '+ str(step)
                strins = strins +  ',' + str(split) + ' entropy gap '
                strins = strins + str(loss.item()) + ' bits loss'
                strins = strins + '(loss ' + str(loss.item()) + ','
                strins = strins + 'data ' + str(table_bits)
                strins = strins +' ' +str(lr) + ' lr'
                print(strins)
            else:
                strins = 'Epoch ' + str(epoch_num)
                strins = strins + ' Iter ' + str(step) + ' '
                strins = strins + str(split) + ' loss '
                print(strins)
                # print('Epoch {} Iter {}, {} loss {:.4f} nats / {:.4f} bits'.
                #       format(epoch_num,
                #              step,
                #              split,
                #              loss.item(),
                #              loss.item()))

        if split == 'train':
            opt.zero_grad()
            loss.backward()
            opt.step()
            # if args.rt:
            #     state = state.detach()
            # print("sss")
            # if(schedu!=None):
            #     schedu.step()

        if verbose:
            # TODO
            # print('%s epoch average loss: %f' % (split, np.mean(losses)))
            pass
    # 得重新弄。
    # if isinstance(model, transformer.Transformer):
    #
    #     df = pd.DataFrame(data=qloss.cardsl)
    #     df.to_csv('cardTest.csv')
    # return 0
    if return_losses:
        return losses
    return np.mean(losses)


def ReportModel(model, blacklist=None):
    ps = []
    for name, p in model.named_parameters():
        if blacklist is None or blacklist not in name:
            ps.append(np.prod(p.size()))
    num_params = sum(ps)
    mb = num_params * 4 / 1024 / 1024
    print('Number of model parameters: {} (~= {:.1f}MB)'.format(num_params, mb))
    print(model)
    return mb


def getModelSize(model):
    param_size = 0
    param_sum = 0
    for param in model.parameters():
        param_size += param.nelement() * param.element_size()
        param_sum += param.nelement()
    buffer_size = 0
    buffer_sum = 0
    for buffer in model.buffers():
        buffer_size += buffer.nelement() * buffer.element_size()
        buffer_sum += buffer.nelement()
    all_size = (param_size + buffer_size) / 1024 / 1024
    print('模型总大小为：{:.3f}MB'.format(all_size))
    return (param_size, param_sum, buffer_size, buffer_sum, all_size)

def InvertOrder(order):
    if order is None:
        return None
    # 'order'[i] maps nat_i -> position of nat_i
    # Inverse: position -> natural idx.  This it the 'true' ordering -- it's how
    # heuristic orders are generated + (less crucially) how Transformer works.
    nin = len(order)
    inv_ordering = [None] * nin
    for natural_idx in range(nin):
        inv_ordering[order[natural_idx]] = natural_idx
    return inv_ordering

import Rmade2
def MakeMade(scale, cols_to_train, seed, fixed_ordering=None):
    if args.inv_order:
        print('Inverting order!')
        fixed_ordering = InvertOrder(fixed_ordering)

    model = Rmade.MADE(
        nin=len(cols_to_train),
        hidden_sizes=[scale] *
        args.layers if args.layers > 0 else [512, 256, 512, 128, 1024],
        nout=sum([c.DistributionSize() for c in cols_to_train]),
        input_bins=[c.DistributionSize() for c in cols_to_train],
        input_encoding=args.input_encoding,
        output_encoding=args.output_encoding,
        embed_size=32,
        seed=seed,
        do_direct_io_connections=args.direct_io,
        natural_ordering=False if seed is not None and seed != 0 else True,
        residual_connections=args.residual,
        fixed_ordering=fixed_ordering,
        column_masking=args.column_masking,
        # part=2,
    ).to(DEVICE)

    return model



def MakeConvMade(scale, cols_to_train, seed, groups=32, channels=96, fixed_ordering=None):
    if args.inv_order:
        print('Inverting order!')
        fixed_ordering = InvertOrder(fixed_ordering)

    model = madeplus.ConvMADE(
        nin=len(cols_to_train),
        hidden_sizes=[scale] *
        args.layers if args.layers > 0 else [512, 256, 512, 128, 1024],
        nout=sum([c.DistributionSize() for c in cols_to_train]),
        input_bins=[c.DistributionSize() for c in cols_to_train],
        input_encoding=args.input_encoding,
        output_encoding=args.output_encoding,
        batchsize=args.bs,
        embed_size=32,
        seed=seed,
        convblocknum=args.convblocknum,
        do_direct_io_connections=args.direct_io,# 这里貌似不需要，使用在fc中的
        natural_ordering=False if seed is not None and seed != 0 else True,
        residual_connections=args.residual,
        fixed_ordering=fixed_ordering,
        column_masking=args.column_masking,
        kernel_size=args.kernelsize,
        kernel_group=groups,
        channels=channels,
        hasshuffle=args.shuffle
    ).to(DEVICE)

    return model


def MakeTransformer(table, fixed_ordering, seed=None):
    return transformer.Transformer(
        table=table,
        num_blocks=args.blocks,
        d_model=args.dmodel,
        d_ff=args.dff,
        num_heads=args.heads,
        # nin=len(table.columns),
        # input_bins=[c.DistributionSize() for c in table.columns],
        use_positional_embs=True,
        activation=args.transformer_act,
        fixed_ordering=fixed_ordering,
        column_masking=args.column_masking,
        seed=seed,
    ).to(DEVICE)

def MakeRTransformer(cols_to_train):
    return RTransformer.BlockRecurrentDecoder(
        num_tokens=args.numtokens,
        d_model=args.numtokens,
        nin=len(cols_to_train),
        input_bins=[c.DistributionSize() for c in cols_to_train],
        use_positional_embs=True,
        isresidual=args.residualrt
    ).to(DEVICE)


def InitWeight(m):
    if type(m) == made.MaskedLinear or type(m) == nn.Linear:
        # Fills the input Tensor with values according to the method described in
        # Understanding the difficulty of training deep feedforward neural networks
        # The resulting tensor will have values sampled from \mathcal{U}(-a, a)U(−a,a) where
        nn.init.xavier_uniform_(m.weight)
        nn.init.zeros_(m.bias)
    if type(m) == nn.Embedding:
        nn.init.normal_(m.weight, std=0.02)


def TrainTask(seed=0):
    torch.manual_seed(0)
    np.random.seed(0)

    assert args.dataset in ['dmv-tiny', 'dmv']
    if args.dataset == 'dmv-tiny':
        table = datasets.LoadDmv('dmv-tiny.csv')
    elif args.dataset == 'dmv':
        table = datasets.LoadDmv()
    s = table.data.fillna(value=0).groupby([c.name for c in table.columns
                                           ]).size()
    table_bits = Entropy(
        table,s
        , [2])[0]
    fixed_ordering = None

    if args.order is not None:
        print('Using passed-in order:', args.order)
        fixed_ordering = args.order

    print(table.data.info())

    table_train = table

    if args.heads > 0:
        model = MakeTransformer(table=table,
                                fixed_ordering=fixed_ordering,
                                seed=seed)
    else: # 这里还没处理数据
        if args.dataset in ['dmv-tiny', 'dmv']:
            if args.conv:
                model = MakeConvMade(
                    scale=args.fc_hiddens,
                    cols_to_train=table.columns,
                    seed=seed,
                    fixed_ordering=fixed_ordering,
                    groups=args.convgroup,
                    channels=args.channels
                )
            else:
                if args.rt:
                    model = MakeRTransformer(cols_to_train=table.columns)
                else:
                    model = MakeMade(
                        scale=args.fc_hiddens,
                        cols_to_train=table.columns,
                        seed=seed,
                        fixed_ordering=fixed_ordering,
                    )
        else:
            assert False, args.dataset

    mb = ReportModel(model)

    if not isinstance(model, transformer.Transformer):
        if not isinstance(model, RTransformer.BlockRecurrentDecoder):
            if not isinstance(model, madeplus.ConvMADE):
                if not isinstance(model, RTSimple.BlockRecurrentDecoder):

                    print('Applying InitWeight()')
                    model.apply(InitWeight)

    if isinstance(model, transformer.Transformer) or isinstance(model, RTransformer.BlockRecurrentDecoder) or \
            isinstance(model, RTSimple.BlockRecurrentDecoder):
        opt = torch.optim.Adam(
            list(model.parameters()),
            2e-4,
            betas=(0.9, 0.98),
            eps=1e-9,
        )
    else:
        opt = torch.optim.Adam(list(model.parameters()), 2e-4)
        # optimizer = torch.optim.SGD(list(model.parameters()), lr=2e-4, momentum=0.9)
        # schedu = torch.optim.lr_scheduler(opt, gamma=0.98)
        # scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=0.1)  # 设置学习率下降策略

    # batch size
    bs = args.bs
    log_every = 200

    train_data = common.TableDataset(table_train)
    import util.datasetUtil as datautl
    traindata=train_data
    testdata = train_data
    validationdata = train_data

    train_losses = []
    train_start = time.time()
    minmodel=model
    # str1=''
    # modelsapt = []
    for epoch in range(args.epochs):

        # mean_epoch_train_loss = RunEpoch('train',
        #                                  model,
        #                                  opt,
        #                                  train_data=train_data,
        #                                  val_data=train_data,
        #                                  batch_size=bs,
        #                                  epoch_num=epoch,
        #                                  log_every=log_every,
        #                                  table_bits=table_bits)
        mean_epoch_train_loss = RunEpoch('train',
                                         model,
                                         opt,
                                         table=table,
                                         train_data=traindata,
                                         val_data=validationdata,
                                         batch_size=bs,
                                         epoch_num=epoch,
                                         log_every=log_every,
                                         table_bits=table_bits)
        minmodel = model
        if True:
            model_nats = np.mean(mean_epoch_train_loss)
            model_bits = model_nats / np.log(2)
            # model.model_bits = model_bits
            model.model_bits = model_bits
            PATH = 'models/{}epoch-loss{}-{}-{:.1f}MB-model{:.3f}-data{:.3f}-{}epochs.pt'.format(
                 epoch, mean_epoch_train_loss, args.dataset, mb, model.model_bits, table_bits,
                args.epochs)
            os.makedirs(os.path.dirname(PATH), exist_ok=True)
            torch.save(model.state_dict(), PATH)
            print('Saved to:')
            print(PATH)
        if epoch % 1 == 0:
            print('epoch {} train loss {:.4f} nats / {:.4f} bits'.format(
                epoch, mean_epoch_train_loss,
                mean_epoch_train_loss / np.log(2)))
            since_start = time.time() - train_start
            print('time since start: {:.1f} secs'.format(since_start))

        train_losses.append(mean_epoch_train_loss)  # 这个变量都没用过，是不是删代码了？这个想来是作图用的。

    print('Training done; evaluating likelihood on full data:')
    all_losses = RunEpoch('test',
                          minmodel,
                          table=table,
                          test_data=testdata,
                          opt=None,
                          batch_size=1024,
                          log_every=500,
                          table_bits=table_bits,
                          return_losses=True)
    model_nats = np.mean(all_losses)
    model_bits = model_nats / np.log(2)
    #model.model_bits = model_bits
    minmodel.model_bits = model_bits

    if fixed_ordering is None:
        if seed is not None:
            # PATH = 'models/{}-{:.1f}MB-model{:.3f}-data{:.3f}-{}-{}epochs-seed{}.pt'.format(
            #     args.dataset, mb, model.model_bits, table_bits, model.name(),
            #     args.epochs, seed)
            PATH = 'models/{}-{:.1f}MB-model{:.3f}-data{:.3f}-{}-{}epochs-seed{}.pt'.format(
                args.dataset, mb, minmodel.model_bits, table_bits, minmodel.name(),
                args.epochs, seed)
        else:
            # PATH = 'models/{}-{:.1f}MB-model{:.3f}-data{:.3f}-{}-{}epochs-seed{}-{}.pt'.format(
            #     args.dataset, mb, model.model_bits, table_bits, model.name(),
            #     args.epochs, seed, time.time())
            PATH = 'models/{}-{:.1f}MB-model{:.3f}-data{:.3f}-{}-{}epochs-seed{}-{}.pt'.format(
                args.dataset, mb, minmodel.model_bits, table_bits, minmodel.name(),
                args.epochs, seed, time.time())
    else:
        annot = ''
        if args.inv_order:
            annot = '-invOrder'

        # PATH = 'models/{}-{:.1f}MB-model{:.3f}-data{:.3f}-{}-{}epochs-seed{}-order{}{}.pt'.format(
        #     args.dataset, mb, model.model_bits, table_bits, model.name(),
        #     args.epochs, seed, '_'.join(map(str, fixed_ordering)), annot)
        PATH = 'models/{}-{:.1f}MB-model{:.3f}-data{:.3f}-{}-{}epochs-seed{}-order{}{}.pt'.format(
            args.dataset, mb, minmodel.model_bits, table_bits, minmodel.name(),
            args.epochs, seed, '_'.join(map(str, fixed_ordering)), annot)
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    torch.save(minmodel.state_dict(), PATH)
    print('Saved to:')
    print(PATH)


TrainTask()
