#!/bin/bash
set -ex
pushd datasets
wget https://www.dropbox.com/s/akviv6e9xi0tl00/Vehicle__Snowmobile__and_Boat_Registrations.csv
popd
