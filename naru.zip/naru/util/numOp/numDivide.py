import numpy as np

def allocation_amount(num_people, amount):
    # 生成小数随机数
    a = [np.random.uniform(0, amount) for i in range(num_people-1)]
    # 生成整数随机数
    # a = [np.random.randint(0, amount) for i in range(num_people-1)]
    a.append(0)
    a.append(amount)
    a.sort()
    # print(a)
    b = [a[i+1]-a[i] for i in range(num_people)]  # 列表推导式，计算列表中每两个数之间的间隔
    # print(b)
    b = np.array(b)
    return b


if __name__ == '__main__':
    s = allocation_amount(2, 0.1)
    print("======")
    print(s)