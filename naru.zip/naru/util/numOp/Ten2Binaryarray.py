import numpy as np
# 将十进制转为二进制的数组。
import torch


def Ten2Binary(num, fixed_length):
    binary_str = bin(num)[2:]
    if len(binary_str)< fixed_length:
        binary_str = '0' * (fixed_length - len(binary_str)) + binary_str
    binary_array = [int(x) for x in binary_str]
    return binary_array

if __name__ == '__main__':
    dec_array = np.random.randint(low=0, high=256, size=(100, 1))
    # binary_x = torch.tensor([2**i for i in range(100)], dtype=torch.float32)
    x = torch.randint(0,2**12,[1024])
    binary_x=[]
    for i in range(1024):
        binary_str = bin(x[i])[2:].zfill(12)
        binary_num = [int(c) for c in binary_str]
        binary_x.append(binary_num)
    binary_x = torch.tensor(binary_x)
    binary_x


    # bin_array = np.unpackbits(dec_array.astype(np.uint8), axis=1)
    # print(bin_array.shape)
    # if bin_array.shape[1] < 8:
    #     zeros = np.zeros((bin_array.shape[0], 8 - bin_array.shape[1]), dtype=np.uint8)
    #     bin_array = np.hstack((bin_array, zeros))
    # print(bin_array)
    # # s = Ten2Binary(999, 12)
    # print(s)
