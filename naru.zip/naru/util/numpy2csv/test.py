import csv
import sys

import numpy
np_array = numpy.asarray([ [1,2,3]])


with open('out22.csv', 'w', newline='') as fp:
    writer = csv.writer(fp, quoting=csv.QUOTE_NONNUMERIC)
    for i in range(5):
        #writer.writerow(np_array.dtype.names)
        writer.writerows(np_array.tolist())

with open('out22.csv', 'w', newline='') as fp:
    writer = csv.writer(fp, quoting=csv.QUOTE_NONNUMERIC)
    for i in range(5):
        #writer.writerow(np_array.dtype.names)
        writer.writerows(np_array.tolist())
sys.exit()