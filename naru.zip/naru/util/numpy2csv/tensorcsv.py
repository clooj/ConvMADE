import pandas as pd
import torch
import numpy as np
# dt1 = pd.read_csv("cast_info.csv").values
# dt1 = pd.read_csv("movie_info.csv").values
# dt1 = pd.read_csv("movie_companies.csv").values
# dt1 = pd.read_csv("movie_info_idx.csv").values
#dt1 = pd.read_csv("movie_keyword.csv").values
dt1 = pd.read_csv("title.csv").values
dt1 = torch.from_numpy(dt1)
dt1 = dt1.reshape(-1)
dt1 = dt1.numpy()
dt1 = pd.DataFrame(dt1)
num = dt1.nunique()
print()