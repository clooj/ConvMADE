import torch
import gc
def getResidentTensor():
    i = 0
    j = 0
    for obj in gc.get_objects():
        try:
            if torch.is_tensor(obj) or (hasattr(obj, 'data') and torch.is_tensor(obj.data)):
                # print(type(obj), obj.size(), id(obj))
                i = i + 1
                if isinstance(obj, torch.Tensor) and not isinstance(obj, torch.nn.parameter.Parameter):
                    print(type(obj), obj.size(), id(obj))
                    j = j + 1
                #     del obj
        except:
            pass
    print(i, j)

def getSpecialSizeResidentTensor(size:torch.Size):
    for obj in gc.get_objects():
        try:
            if (torch.is_tensor(obj) or (hasattr(obj, 'data') and torch.is_tensor(obj.data))) and obj.shape==size:
                print(type(obj), obj.size(), obj.device, id(obj))
                # i = i + 1
                # if isinstance(obj, torch.Tensor) and not isinstance(obj, torch.nn.parameter.Parameter):
                #     j = j + 1
                #     del obj
        except:
            pass

def geta():
    a = torch.Size([64,8,64,64])
    getSpecialSizeResidentTensor(a)


def getb():
    a = torch.Size([64,64])
    getSpecialSizeResidentTensor(a)