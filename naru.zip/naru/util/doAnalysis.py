import numpy as np
import pandas as pd

s = np.log(2)
print(s)
table = pd.read_csv(r"analysis.csv")
x=table[['epoch']]
z = x.value_counts()
print(z)