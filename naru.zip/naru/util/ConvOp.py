import torch.nn as nn

class Unsqueeze(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim


    def forward(self, x):
        x = x.unsqueeze(self.dim)
        #x = x.squeeze(1)
        return x


class Squeeze(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim


    def forward(self, x):
        # x = x.unsqueeze(self.dim)
        x = x.squeeze(self.dim)
        return x
