import csv
import os

import pandas as pd

dir = r"C:\Users\ren\PycharmProjects\naru\csv"
# 截取某一段文件名重命名文件
def renamefile(filedir=dir, ruls=r'[0-9]*epoch-loss.*-dmv-tiny.*-convmade'):
    fileNameList = os.listdir(filedir)
    import re
    rule = re.compile(ruls)
    for fileName in fileNameList:
        newFilename = re.findall(rule, str(fileName))[0]
        newFilename = newFilename+".csv"
        os.rename(os.path.join(filedir, fileName),os.path.join(filedir, newFilename))

def readCsvColumn(CsvFileName, ColumnName):
    table = pd.read_csv(CsvFileName)
    x = table[[ColumnName]]
    return x


def analysisCsv(filedir=dir, ruls=r'[0-9]*epoch-loss.*-dmv-tiny.*-convmade.*pt'):
    fileNameList = os.listdir(filedir)
    import re
    rule = re.compile(ruls)
    data = pd.DataFrame()
    rule = re.compile(r'[0-9]*epoch')
    rule2 = re.compile(r'[0-9]*')
    list = []
    for fname in fileNameList:
        sts = re.findall(rule, fname)[0]
        list = list + [sts]
    data = data.reindex(columns=list)
    for fileName in fileNameList:
        x = readCsvColumn(filedir + '/' + fileName, 'err')

        columnName = re.findall(rule, fileName)[0]
        x = x.sort_values(by='err', ascending=False)
        x = x.reset_index(drop=True)
        x = x.rename(columns={'err' : columnName})

        aix = int(re.findall(rule2, columnName)[0])
        data[columnName] = x
        #data = pd.concat([data, x],aixs=aix)

    data.to_csv('result2.csv', index=False, header=True)

analysisCsv()





