import logging
import re

import pandas as pd
import torch
import numpy as np
import argparse
import collections

import RTransformer
import transformer
import estimators as estimators_lib
from eval_model import LoadOracleCardinalities, MakeTable, \
    MakeRTransformer, MakeMade, MakeConvMade,MakeTransformer, ReportModel, RunN, \
    Query, ErrorMetric
import glob
torch.backends.cudnn.deterministic = False
torch.backends.cudnn.benchmark = True

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
print('Device', DEVICE)
def setParser():
    parser = argparse.ArgumentParser()

    parser.add_argument('--inference-opts',
                        action='store_true',
                        help='Tracing optimization for better latency.')

    parser.add_argument('--num-queries', type=int, default=20, help='# queries.')
    parser.add_argument('--dataset', type=str, default='dmv-tiny', help='Dataset.')
    parser.add_argument('--errcsv',
                        type=str,
                        default='results.csv',
                        help='Save result csv to what path?')
    parser.add_argument('--glob',
                        type=str,
                        help='Checkpoints to glob under models/.')
    parser.add_argument('--blacklist',
                        type=str,
                        help='Remove some globbed checkpoint files.')
    parser.add_argument('--psample',
                        type=int,
                        default=2000,
                        help='# of progressive samples to use per query.')
    parser.add_argument(
        '--column-masking',
        action='store_true',
        help='Turn on wildcard skipping.  Requires checkpoints be trained with '\
        'column masking.')
    parser.add_argument('--order',
                        nargs='+',
                        type=int,
                        help='Use a specific order?')
    # conv
    parser.add_argument('--conv', action='store_true')
    parser.add_argument('--shuffle', action='store_true')
    parser.add_argument('--convgroup', type=int, default=32)
    parser.add_argument('--channels', type=int, default=96)
    parser.add_argument('--convblocknum', type=int, default=1)
    parser.add_argument('--kernelsize', type=int, default=9)


    # MADE.
    parser.add_argument('--fc-hiddens',
                        type=int,
                        default=128,
                        help='Hidden units in FC.')
    parser.add_argument('--layers', type=int, default=4, help='# layers in FC.')
    parser.add_argument('--residual', action='store_true', help='ResMade?')
    parser.add_argument('--direct-io', action='store_true', help='Do direct IO?')
    parser.add_argument(
        '--inv-order',
        action='store_true',
        help='Set this flag iff using MADE and specifying --order. Flag --order'\
        'lists natural indices, e.g., [0 2 1] means variable 2 appears second.'\
        'MADE, however, is implemented to take in an argument the inverse '\
        'semantics (element i indicates the position of variable i).  Transformer'\
        ' does not have this issue and thus should not have this flag on.')
    parser.add_argument(
        '--input-encoding',
        type=str,
        default='binary',
        help='Input encoding for MADE/ResMADE, {binary, one_hot, embed}.')
    parser.add_argument(
        '--output-encoding',
        type=str,
        default='one_hot',
        help='Iutput encoding for MADE/ResMADE, {one_hot, embed}.  If embed, '
        'then input encoding should be set to embed as well.')

    # Transformer.
    parser.add_argument(
        '--heads',
        type=int,
        default=0,
        help='Transformer: num heads.  A non-zero value turns on Transformer'\
        ' (otherwise MADE/ResMADE).'
    )
    parser.add_argument('--blocks',
                        type=int,
                        default=2,
                        help='Transformer: num blocks.')
    parser.add_argument('--dmodel',
                        type=int,
                        default=32,
                        help='Transformer: d_model.')
    parser.add_argument('--dff', type=int, default=128, help='Transformer: d_ff.')
    parser.add_argument('--transformer-act',
                        type=str,
                        default='gelu',
                        help='Transformer activation.')

    # RT
    parser.add_argument('--rt', action='store_true')
    parser.add_argument('--numtokens', type=int, default=64)

    # Estimators to enable.
    parser.add_argument('--run-sampling',
                        action='store_true',
                        help='Run a materialized sampler?')
    parser.add_argument('--run-maxdiff',
                        action='store_true',
                        help='Run the MaxDiff histogram?')
    parser.add_argument('--run-bn',
                        action='store_true',
                        help='Run Bayes nets? If enabled, run BN only.')

    # Bayes nets.
    parser.add_argument('--bn-samples',
                        type=int,
                        default=200,
                        help='# samples for each BN inference.')
    parser.add_argument('--bn-root',
                        type=int,
                        default=0,
                        help='Root variable index for chow liu tree.')
    # Maxdiff
    parser.add_argument(
        '--maxdiff-limit',
        type=int,
        default=30000,
        help='Maximum number of partitions of the Maxdiff histogram.')
    return parser


# parse string to query arguments
def parse(sql):
    col=[]
    val=[]
    op=[]
    reco = re.compile(r'[`](.*)[`]')
    reop = re.compile(r'[`](.*)[\']')
    reva = re.compile(r'[\'](.*)[\']')
    strList = sql.split("&")
    for str in strList:
        recolstr = re.findall(reco, str)
        col.append(recolstr[0])
        revastr = re.findall(reva, str)
        val.append(revastr[0])
        reopstr = re.findall(reop, str)
        reopstr = re.findall(reop, reopstr[0])
        reopstr = reopstr[0].strip()
        if reopstr == '==':
            reopstr='='
        op.append(reopstr)

    col = np.array(col)
    op = np.array(op)
    val = np.array(val)
    return col, op, val
    # pass

def setQuery(col, op, val, all_cols,rng,table, args, return_col_idx=False):
    # s = table.data.iloc[rng.randint(0, table.cardinality)]
    print("*"*12)
    idxs = []
    for i in col:
        idx = 0
        for j in all_cols:
            if j.name == i:
                idxs.append(idx)
            idx = idx + 1
    # idxs = np.where(all_cols.name == col[:, None])[1]
    # print(idxs)
    idxs = np.array(idxs)
    # if args.dataset in ['dmv', 'dmv-tiny']:
    #     va
    cols = np.take(all_cols, idxs)
    ops = op
    vals = val.astype(object)
    if args.dataset in ['dmv', 'dmv-tiny']:
        for i in range(vals.size):
            if cols[i].name=='Reg Valid Date':
                vals[i] = pd.to_datetime(vals[i])
                # vals[i] = vals[i].to_datetime64()

    return cols, ops, vals

    # pass

def getModel(args):

    all_ckpts = glob.glob('C:/Users/ren/PycharmProjects/naru/models/{}'.format(args.glob))
    if args.blacklist:
        all_ckpts = [ckpt for ckpt in all_ckpts if args.blacklist not in ckpt]

    selected_ckpts = all_ckpts

    print('ckpts', selected_ckpts)

    if not args.run_bn:
        # OK to load tables now
        table, train_data, oracle_est = MakeTable(args)
        cols_to_train = table.columns

    Ckpt = collections.namedtuple(
        'Ckpt', 'epoch model_bits bits_gap path loaded_model seed')
    parsed_ckpts = []

    for s in selected_ckpts:
        if args.order is None:
            if not args.rt:
                z = re.match('.+model(-{0,1}[\d\.]+)-data(-{0,1}[\d\.]+).+seed([\d\.]+).*.pt',
                             s)
                if z is None:
                    z = re.match('.+model(-{0,1}[\d\.]+)-data(-{0,1}[\d\.]+).*.pt',
                                 s)
            else:
                z = re.match('.+model(-{0,1}[\d\.]+)-data(-{0,1}[\d\.]+).*.pt',
                             s)
        else:
            z = re.match(
                '.+model(-{0,1}[\d\.]+)-data(-{0,1}[\d\.]+).+seed([\d\.]+)-order.*.pt', s)
        assert z
        model_bits = float(z.group(1))
        data_bits = float(z.group(2))
        # if not args.rt:
        #     seed = int(z.group(3))
        seed = 0
        bits_gap = model_bits - data_bits

        order = None
        if args.order is not None:
            order = list(args.order)

        # TODO 这里需要一个MakeRT
        if args.heads > 0:
            model = MakeTransformer(cols_to_train=table.columns,
                                    fixed_ordering=order,
                                    seed=seed,
                                    args=args)
        else:
            if args.dataset in ['dmv-tiny', 'dmv']:
                if args.conv:
                    model = MakeConvMade(
                        scale=args.fc_hiddens,
                        cols_to_train=table.columns,
                        seed=seed,
                        fixed_ordering=order,
                        args=args
                    )
                else:
                    if args.rt:
                        model = MakeRTransformer(cols_to_train=table.columns, args=args)
                    else:
                        model = MakeMade(
                            scale=args.fc_hiddens,
                            cols_to_train=table.columns,
                            seed=seed,
                            fixed_ordering=order,
                            args=args
                        )
            else:
                assert False, args.dataset

        assert order is None or len(order) == model.nin, order

        ReportModel(model)
        print('Loading ckpt:', s)
        model.load_state_dict(torch.load(s))
        parsed_ckpts.append(
            Ckpt(path=s,
                 epoch=None,
                 model_bits=model_bits,
                 bits_gap=bits_gap,
                 loaded_model=model,
                 seed=seed))
    return parsed_ckpts, table, cols_to_train, oracle_est



def getEstminate(args, parsed_ckpts, table, oracle_est):
    estimators = [
        estimators_lib.ProgressiveSampling(c.loaded_model,
                                           table,
                                           args.psample,
                                           device=DEVICE,
                                           shortcircuit=args.column_masking)
        for c in parsed_ckpts
    ]
    for est, ckpt in zip(estimators, parsed_ckpts):
        est.name = str(est) + '_{}_{:.3f}'.format(ckpt.seed, ckpt.bits_gap)

    if args.inference_opts:
        print('Tracing forward_with_encoded_input()...')
        for est in estimators:
            encoded_input = est.model.EncodeInput(
                torch.zeros(args.psample, est.model.nin, device=DEVICE))

            # NOTE: this line works with torch 1.0.1.post2 (but not 1.2).
            # The 1.2 version changes the API to
            # torch.jit.script(est.model) and requires an annotation --
            # which was found to be slower.
            est.traced_fwd = torch.jit.trace(
                est.model.forward_with_encoded_input, encoded_input)

    if args.run_sampling:
        SAMPLE_RATIO = {'dmv': [0.0013]}  # ~1.3MB.
        for p in SAMPLE_RATIO.get(args.dataset, [0.01]):
            estimators.append(estimators_lib.Sampling(table, p=p))

    if args.run_maxdiff:
        estimators.append(
            estimators_lib.MaxDiffHistogram(table, args.maxdiff_limit))

    # Other estimators can be appended as well.
    return estimators



if __name__ == '__main__':
    args = setParser().parse_args()
    parsed_ckpts, table, cols_to_train, oracle_est = getModel(args)
    # 这里想错了，应该是直接置为None，因为是自定义搞这玩意的。
    oracle_cards = LoadOracleCardinalities(args)
    estimators = getEstminate(args=args,
                                 parsed_ckpts=parsed_ckpts,
                                 table=table,
                                 oracle_est=oracle_est)
    rng = np.random.RandomState(1234)
    while True:
        try:
            strinput = input()
            col, op, val = parse(strinput)
            estcard=0
            card=0
            if len(estimators):
                query = setQuery(col, op, val, all_cols=cols_to_train,rng=1234,table=table, args=args, return_col_idx=False)
                estcard,card = Query(estimators=estimators,
                      oracle_card=None,
                      query=query,
                      table=table,
                      oracle_est=oracle_est )

            err = ErrorMetric(estcard, card)

            print("="*7+"output"+"="*7)
            print(estcard, card, err)
            print("="*20)
        except Exception as result:
            logging.exception(result)
    # sql = "`Record Type` == 'VEH' & `Registration Class` <= 'PAS' & `State` == 'NY' & `County` == 'TIOGA' & `Body Type` == 'SUBN' & `Fuel Type` == 'GAS' & `Reg Valid Date` == '2020-06-08T00:00:00.000000000' & `Color` == 'WH' & `Scofflaw Indicator` == 'N' & `Suspension Indicator` >= 'N' & `Revocation Indicator` <= 'N'"
    # col,op,val= parse(sql)


