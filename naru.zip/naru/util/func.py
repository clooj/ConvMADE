import time

import torch

def adaptive(func, *args, **argv):
    tmp=[]
    # f = 0
    for i in args:
        # args[i]=args[i].data.to('cuda')
        # args[f]=args[f].to('cuda')
        if torch.is_tensor(i):
            tmp.append(i.to('cuda'))
        else:
            tmp.append(i)
    for i in argv:
        if torch.is_tensor(argv[i]):
            argv[i] = argv[i].to('cuda')
        # argv[i] = argv[i].to('cuda')
    args1 = func(*tmp, **argv)
    tmp = []

    if torch.is_tensor(args1):
        return args1.to('cpu')
    else:
        return args1
    # for i in args1:
    #     if torch.is_tensor(i):
    #         # tmp.append(i.to('cpu'))
    #         return i.to('cpu')
    #     else:
    #         # tmp.append(i)
    #         return i

    # for i in argv:
    #     argv[i] = argv[i].to('cuda')
    # tmp = tuple(tmp)
    return tuple(tmp)


def tset(a, b, c):
    return a, b, c, 1

if __name__ == '__main__':
    # func = tset
    # i = torch.rand((64, 64)).to('cpu')
    # # i = i.to('cpu')
    # j= torch.rand((64, 64)).to('cpu')
    # k = torch.rand((1024, 13)).to('cpu')
    # # j = j.to('cpu')
    # a, b, c, d= adaptive(func, (i,j))
    # print(a, b, c)
    a = torch.rand((2000, 64, 64)).to('cpu')
    b = torch.rand((2000, 64, 64)).to('cpu')
    t1 = time.time()
    # q = torch.concat((a, b), dim=2)
    for i in range(int(1000)):
        a = a + b
    t2 = time.time()
    tt = t2-t1

    c = torch.rand((2000, 64, 64)).to('cuda')
    d = torch.rand((2000, 64, 64)).to('cuda')
    t3 = time.time()
    for i in range(int(1000)):
        c = c + d
    # s2 = torch.concat((c, d), dim=2)
    # s = s+s
    t4 = time.time()
    tt1 = t4 - t3
    tt1
    # import RTransformer as rt
    # import time
    # attn = rt.BlockRecurrentDecoder(num_tokens=64, d_model=64, nin=11,
    #                              input_bins=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11])
    #
    #
    # x = torch.rand((1024, 11)).to('cpu')
    # tt1 = time.time()
    # for i in range(int(8000)):
    #     val, state = adaptive(attn, x)