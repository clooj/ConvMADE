import torch
import torch.nn.functional as F

logit = torch.rand([11,12])
target = torch.rand([11,12])
s = F.cross_entropy(logit, target)

s