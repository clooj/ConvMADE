import torch
import util.gpu.Current_Resident_Tensor as util
li = []
# for i in range(int(117)):
    # li.append(torch.rand((64, 11)).to('cuda'))


# util.getResidentTensor()

li = torch.rand((64, 11)).to('cuda')
s = li.shape
a = type(s)
if(li.shape==s):
    print("==")
print(type(s))
util.getResidentTensor()
print("=======")
del li
util.getResidentTensor()
li