
import torch
a = torch.rand(1024,64,64)
b = a[0:100]
b