
import torch
# ValueError: only one element tensors can be converted to Python scalars
a = torch.rand([64,64]).item()
a
