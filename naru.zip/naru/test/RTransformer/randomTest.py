import random

if __name__ == '__main__':
    times=0
    for i in range(20000000):
        x = random.uniform(0,10000)
        if x<=1:
            times = times + 1

    times

