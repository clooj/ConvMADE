import time

import RTransformer
from RTransformer import *

import torch

if __name__ == '__main__':
    attn = RTransformer.BlockRecurrentDecoder(num_tokens=64, d_model=64, nin=11,
                                 input_bins=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11])
    attn.to('cuda')
    t1 = time.time()
    x = torch.zeros((1024, 11)).to('cuda')
    state = None
    for i in range(int(8000)):


        x1, state = attn(x, state)
        state = state.detach()

    t2 = time.time()
    times = t2 - t1
    print(times)
