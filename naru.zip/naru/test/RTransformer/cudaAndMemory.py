import sys
import time



import torch

import RTransformer

torch.backends.cudnn.enabled = True
torch.backends.cudnn.benchmark = True
# def test():
#     x = torch.rand((1024, 64, 64)).to('cuda')
#     tt1 = time.time()
#     for i in range(int(8000)):
#         if x.is_cuda:
#             x = x.to('cpu')
#         else:
#             x = x.to('cuda')
#     tt2 = time.time()
#     tt = tt2 - tt1
#     t1 = time.time()
#     # x = torch.rand((1024, 64, 64)).to('cuda')
#
#     state = None
#     z = []
#     storg = []
#     for i in range(int(8000)):
#         x = torch.rand((1024, 64, 64)).to('cuda')
#         if i % 4 != 0:
#             x = x.to('cuda')
#         else:
#             x = x.to('cuda')
#         stor = sys.getsizeof(x)
#         storg.append(stor)
#         z.append(x)
#
#     t2 = time.time()
#     times = t2 - t1
#     print(times)

if __name__ == '__main__':
    attn = RTransformer.BlockRecurrentDecoder(num_tokens=64, d_model=64, nin=11,
                                 input_bins=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11])
    # attn =
    attn.to('cuda')

    x = torch.rand((1024, 11)).to('cuda')
    tt1 = time.time()
    state = None
    x = torch.rand((64, 11)).to('cuda')
    import util.gpu.Current_Resident_Tensor as util
    for i in range(int(8000)):
        print(i)
        # with torch.no_grad():

        val, state = attn(x, state)
        # del val, x
        # time.sleep(2)
        # util.getResidentTensor()
        # print("======================================")
        # print(torch.cuda.memory_summary())
        # print("======================================")
        torch.cuda.empty_cache()
        # print(torch.cuda.memory_summary())

