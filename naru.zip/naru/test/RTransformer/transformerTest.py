import RTransformer
import torch
import util.gpu.Current_Resident_Tensor as util
if __name__ == '__main__':
    attn_kwargs = {}
    attn = RTransformer.Attention(64, heads=8, causal=True,**attn_kwargs).to('cuda')
    attn1 = RTransformer.Attention(64, heads=8, causal=False, **attn_kwargs).to('cuda')
    rotary_pos_emb = RTransformer.RotaryEmbedding(8).to('cuda')
    x = torch.rand((2000, 64, 64)).to('cuda')
    device = x.device
    for i in range(int(800000)):
        # pos_emb =
        print(i)
        print("==============")
        pos_emb = rotary_pos_emb(64, device=device)
        # pos_emb = pos_emb.to('cuda')
        x = torch.rand((64, 64, 64)).to('cuda')
        u = attn(x, mask=None, pos_emb=pos_emb)
        w = attn1(x, mask=None, pos_emb=pos_emb)
        util.getResidentTensor()