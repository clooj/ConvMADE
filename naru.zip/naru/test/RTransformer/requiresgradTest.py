
import torch.nn as nn
import torch

def testnnEmbedding():
    embed = nn.Embedding(64,32).cuda()
    nn.init.normal_(embed.weight, std=0.02)
    for i in range(100):
        x = torch.rand((32,64)).long().to('cuda')
        u = embed(x)
        u.detach()

    u.detach()
    u
