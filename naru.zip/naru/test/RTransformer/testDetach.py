import torch
import torch.nn as nn
import torch.nn.functional as F

class Models(nn.Module):
    def __init__(self):
        super(Models, self).__init__()
        self.Layer = nn.LayerNorm(8)
        self.liner = nn.Linear(8, 8)

    def forward(self,x):
        x = self.liner(x)
        x = self.Layer(x)
        return x

    def nll(self):
        return 0.01

if __name__ == '__main__':
    model = Models().to('cuda')
    y = torch.rand([10, 8]).to('cuda')
    opt = torch.optim.Adam(
        list(model.parameters()),
        2e-4,
        betas=(0.9, 0.98),
        eps=1e-9,
    )
    for i in range(100):
        model(y)
        loss = model.nll()

        opt.zero_grad()
        loss.backward()
        opt.step()
