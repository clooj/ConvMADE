import time
import sys
import numpy as np
import util.func as func
import torch
import torch.nn as nn
import torch.nn.functional as F


class ModelInput(nn.Module):
    def __init__(self):
        super(ModelInput, self).__init__()
        self.embeddings = nn.ModuleList()
        for i in range(10):
            self.embeddings.append(nn.Embedding(32,32))
        for e in self.embeddings:
            nn.init.normal_(e.weight, std=0.02)


    # def forward(self,x):
