import torch

i = [1,9]
i.append(10)
for k in i:
    print(k)

num = torch.tensor(0)
print(num.item())
num