import torch

s = torch.rand([2,4])
print(s)
ss = s.sum()
ss