import re

s = './models/dmv-tiny-5.5MB-model-2.452-data11.865-convmade-batchsize200-emb32-channels32-kernelsize9-kernelgroup16-convnum2-binaryInone_hotOut-inputNoEmbIfLeq-colmask1659608024.484901-200epochs-seed0.pt'
z = re.match('.+model(-{0,1}[\d\.]+)-data(-{0,1}[\d\.]+).+seed([\d\.]+).*.pt',
                         s)
x = float(z.group(1))
y = z.group(2)
ss = z.group(3)
print(y)
print(x)
print(ss)