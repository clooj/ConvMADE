import pandas as pd
import numpy as np
raw_data = pd.read_csv('cora/cora.content',sep = '\t', header=None)

ss=0
print(ss)