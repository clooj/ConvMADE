import common


def Entropys(data, bases=None):
    import scipy.stats
    ret = []
    for base in bases:
        assert base == 2 or base == 'e' or base is None
        e = scipy.stats.entropy(data, base=base if base != 'e' else None) # 计算给定概率值的分布熵。
        ret.append(e)
    return ret


def Entropy(name, data, bases=None):
    import scipy.stats
    s = 'Entropy of {}:'.format(name)
    ret = []
    for base in bases:
        assert base == 2 or base == 'e' or base is None
        e = scipy.stats.entropy(data, base=base if base != 'e' else None) # 计算给定概率值的分布熵。
        ret.append(e)
        unit = 'nats' if (base == 'e' or base is None) else 'bits'
        s += ' {:.4f} {}'.format(e, unit)
    print(s)
    return ret
import datasets
def train(seed=0):
    table = datasets.LoadDmv('dmv-tiny.csv')
    table_bits = Entropy(
        table,
        table.data.fillna(value=0).groupby([c.name for c in table.columns
                                           ]).size(), [2])[0]
    print(table_bits)
    train_data = common.TableDataset(table)
    tables = Entropys(train_data)