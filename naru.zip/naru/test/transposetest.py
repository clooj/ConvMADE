import numpy as np
import torch

k = torch.randn(3, 2, 4)
x = k.transpose(1, 2)
print(x.shape)