import ray
from ray import tune
from ray.tune import CLIReporter
from ray.tune.schedulers import ASHAScheduler
def rus(config):
    print("====")
    print(config)
    # print(ass)

tune.run(rus,tune.choice([9,8,7]))