import torch
import torch.nn as nn

w = torch.empty(3, 5)
print(w)
nn.init.zeros_(w)
print(w)