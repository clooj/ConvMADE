a = [8,8,8,8]
b=[i//2 for i in a ]
b