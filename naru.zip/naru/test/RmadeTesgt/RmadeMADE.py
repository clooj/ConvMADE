import torch

model = torch.load("C:/Users/ren/PycharmProjects/naru/models/5epoch-loss14.762419316443177-dmv-6.1MB-model21.298-data19.579-20epochs.pt")
model