import csv

csv_file =r'../../datasets/sss.csv'
new_csv_file = r'../../datasets/a.csv'


import pandas as pd
def addHash():
    files = pd.read_csv(csv_file)
    csvfile = open(csv_file,'r')
    reader = csv.reader(csvfile)
    # reader.
    hashlist = []
    i=0
    for row in reader:
        if i!=0:
            row=str(row)
            hashlist.append(hash(row))
        else:
            i=1
    files['hkv']=hashlist
    files.to_csv(new_csv_file, index=None)


def lookHashditinctRow():
    files = pd.read_csv(new_csv_file)
    s = files['hkv']
    s = s.value_counts()
    s.to_csv(r'./b.csv')
    c1 = sum(s==1)
    print(c1)
    c2 = sum(s<10)
    print(c2)
    c3 = sum(s<50)
    print(c3)
    c4 = sum(s<100)
    print(c4)
    c5 = sum(s<200)
    print(c5)
    c6 = sum(s < 300)
    print(c6)
    c7 = sum(s < 400)
    print(c7)
    c8 = sum(s < 500)
    print(c8)
    c9 = sum(s < 600)
    print(c9)
    c10 = sum(s < 700)
    print(c10)
    c11 = sum(s < 800)
    print(c11)
    c12 = sum(s < 900)
    print(c12)
    c13 = sum(s < 1000)
    print(c13)
    c14 = sum(s < 2000)
    print(c14)
    c15 = sum(s >= 2000)
    print(c15)
    # v = s.unique()
    # vs = s.value_counts()
    # print(s.unique())
    # print()


lookHashditinctRow()
