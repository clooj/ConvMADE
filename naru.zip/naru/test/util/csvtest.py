import pandas as pd

path = r"C:\Users\ren\3D Objects\naru1\0epoch-loss29.582836423601425-dmv-tiny-5.5MB-model42.679-data11.865-convmade.csv"
data = pd.read_csv(path)
z = data[['err']]
import re
rule = re.compile(r'[0-9]*epoch')
columnName = re.findall(rule, path)[0]
data = data.reindex(columns=['a'])
print (z)