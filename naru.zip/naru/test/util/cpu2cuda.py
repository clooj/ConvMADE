import torch.cuda
import pynvml

def change_device(x, device):
    if x.device==device:
        return x
    x = x.to(device)
    return x


def getGpuMemAvailable(gpu_id:int):
    # inf = torch.cuda.get_device_capability(device)
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(gpu_id)
    meminfo = pynvml.nvmlDeviceGetMemoryInfo(handle)
    avai = meminfo.free
    pynvml.nvmlShutdown()
    return avai


if __name__ == '__main__':
    x = torch.cuda.get_device_properties('cuda')
    s = getGpuMemAvailable(0)
    s