import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F


# 简化编码，类似于主键的这类数据，没有必要将过高的资源投入到其编码中去。
import torch_geometric.graphgym


class EncodeSimple(nn.Module):
    def __init__(self,
                 outputDim):
        super.__init__()
        self.outputDim = outputDim
        self.conv1d = nn.Conv1d(in_channels=1, out_channels=self.outputDim, kernel_size=1)

    def forward(self, x):

        x = x.unsqueeze(1)
        x = self.conv1d(x)
        x = x.permute(0, 2, 1)
        return x

def strmethod(strs):
    return strs.format('ooo')


if __name__ == '__main__':
    # conv1 = nn.Conv1d(in_channels=1, out_channels=100, kernel_size=1)
    #
    input2 = torch.randn(1024,1,1)
    # # ss = input2.unsqueeze(2)
    #
    # out = conv1(input2)
    # tt = out.squeeze(2)
    # print(out.size())
    a = torch_geometric.graphgym.GNN()
    a = a(input2)
    a
