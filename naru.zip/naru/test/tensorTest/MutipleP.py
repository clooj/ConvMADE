import numpy as np
from pulp import LpVariable, LpProblem, LpMaximize, LpMinimize, lpSum

# 定义A和b
A = np.array([[1, 2], [3, 4], [5, 6]])
b = np.array([[7], [8], [9]])

# 转换成PuLP可以处理的格式
A_pulp = A.tolist()
b_pulp = b.reshape(-1).tolist()

# 定义线性规划问题
prob = LpProblem("Linear Programming Problem", LpMaximize)

# 定义决策变量x
x = [LpVariable("x{}".format(i), lowBound=0) for i in range(A.shape[1])]

# 定义目标函数
prob += lpSum(x)

# 定义约束条件
for i in range(A.shape[0]):
    prob += lpSum([A_pulp[i][j] * x[j] for j in range(A.shape[1])]) <= b_pulp[i]

# 求解线性规划问题
prob.solve()

# 输出结果
print("Optimal value:", prob.objective.value())
for i in range(A.shape[1]):
    print("x{} = {}".format(i, x[i].value()))