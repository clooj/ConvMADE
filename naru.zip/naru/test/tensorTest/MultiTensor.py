import torch
a = torch.rand(1,3)
b = torch.rand(1,3)
c = a*b
c