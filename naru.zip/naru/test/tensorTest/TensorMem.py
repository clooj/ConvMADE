import torch
a = torch.empty([10_0000_0000,], dtype=torch.float32).to('cuda')

a