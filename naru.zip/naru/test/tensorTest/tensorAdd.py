import torch
import numpy as np
ll = []
a = torch.tensor([0, 0, 0, 1, 1])
ll.append(a)
b = torch.tensor([0, 0, 1, 0, 1])
ll.append(b)
c = torch.tensor([0, 1, 1, 0, 1])
ll.append(c)
d = torch.stack([a, b, c])
# z = torch.logical_or(a, b).to(torch.int)

z = torch.any(d,dim=0)
z