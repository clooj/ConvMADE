import torch
x = torch.randn(1024,2,256)
conv = torch.nn.Conv1d(in_channels=2, out_channels=2,kernel_size=1)
ss = conv(x)
u = [None]*2
u[0] = x[:,0,:]
u[1] = x[:,1,:]
u[0] = torch.unsqueeze(u[0],1)
u[1] = torch.unsqueeze(u[1],1)
z = torch.cat(u,1)
u