import torch

x = torch.tensor([[1, 2], [3, 4]])
print(x)
y = x+torch.tensor([1.0])
print(y)