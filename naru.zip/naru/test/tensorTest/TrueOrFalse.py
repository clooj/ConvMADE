import torch
a = torch.tensor([True,False])
b = a.int()
b