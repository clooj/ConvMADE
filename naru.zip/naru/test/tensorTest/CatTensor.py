import torch

ll = []
for i in range(4):
    ll.append(torch.randn([1024,i+1]))
lt = ll[0]
c = torch.cat(ll, dim=1)
c
# for ten in range(len(ll)-1):
#     c torch.cat(lt, ll[ten+1])