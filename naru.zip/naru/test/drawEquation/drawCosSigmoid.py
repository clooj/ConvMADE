import numpy as np
import matplotlib.pyplot as plt

h0 = [0.4, .6, .8]  # h0取值
lambda0 = [0.03, 0.05, 0.07]  # λ取值
plt.figure(figsize=(6, 4))  # 设置图片大小
x = np.linspace(0, 50, 50)  # 在[0，50)中取50个点
def sigmoid(x):
    s = 1/(1 + np.exp(-x))
    return s

for i in lambda0:
    for h in h0:
        plt.plot(x, sigmoid(np.cos(x)), label='lambda=' + str(i) + ' h=' + str(h))
# plt.plot(x,y,图例内容)
plt.legend()  # 显示图例
plt.show()