import math
import ss
import torchvision.models as models
import torch.nn as nn
import torch
import torch.nn.functional as F
# a = [1, 2, 3, 4]
# b = [5, 6, 7, 8]
# inp = torch.Tensor([a, b, a, b, a, b])
# print(inp)
# print(inp.shape)
x = 55
y = 2**math.ceil(math.log2(x))
z = 2**math.floor(math.log2(x))
u = 7 // 2
print(y)


conv1 = nn.Conv1d(in_channels=1, out_channels=1, kernel_size=3, padding=1)
conv2 = nn.Conv1d(in_channels=1, out_channels=32, kernel_size=9, padding=4)
conv22 = nn.Conv1d(in_channels=32, out_channels=1, kernel_size=9, padding=4)
conv3 = nn.ConvTranspose1d(in_channels=1, out_channels=32, kernel_size=9, stride=2,padding=4)
maxpool = nn.MaxPool1d(kernel_size=9, padding=4)
m = nn.Conv1d(16, 33, 3, stride=2)

#relus =
input = torch.randn(2048, 1, 55)

output = conv2(input)
idx = torch.randperm(output.shape[1])
output1 = output
output2 = output[:,idx].view(output.size())
output3 = nn.functional.relu(output, inplace=True)
bn = nn.BatchNorm1d(32)
# output4 = bn(output3)
# output2 = maxpool(output)

x = [1]
y = [2]
zz = x + y
# x.append([1])
# x.append([2])
# x.pop()
x
output = conv22(output)
output5 = output.squeeze(1)
print(output5.shape)
#output2 = conv32(output)
#output1 = conv31(output)
print(output.shape)
ss = 0