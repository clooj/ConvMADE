import torch
mydict = {"oo":torch.tensor([10])}
print(mydict["oo"])
import numpy as np
import math


def copytest(tensor1,tensor2):
    tensor2.copy_(tensor1)

a = torch.zeros(1, 11).fill_(5)
b = torch.zeros(1, 11).fill_(8)
copytest(a, b)
a
b

# i = 8
# u = math.ceil(math.log2(i))
# array = np.random.randint(0,10,size=10)
# indices = np.where(array == 2)
b = torch.tensor([1,2,3])
a = torch.empty(2,3)
a[:,2]=b

a