import cupy as np
import torch
# tensor([[0.9049, 0.0664, 0.0864]], device='cuda:0')
A = np.array([[1], [0], [0]])
B = np.array([[0.90487],[0.06637],[0.08643]])

X, residuals, rank, s = np.linalg.lstsq(A, B, rcond=None)
x = torch.tensor(X[0])
# 构造多个常数向量b
B = np.array([[1, 2], [3, 4], [4, 5], [6, 7]])

# 构造系数矩阵A
A = np.array([[1, 1, 1], [2, 2, 2], [3, 3, 3], [4, 4, 4]])

# 求解多个线性方程组的最小二乘解
A = np
X, residuals, rank, s = np.linalg.lstsq(A, B, rcond=None)

# 输出解向量X
print(X.T)