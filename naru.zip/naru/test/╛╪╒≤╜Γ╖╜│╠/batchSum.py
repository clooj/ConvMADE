import numpy as np

# 生成随机的Ax=b问题
batch_size = 5
n = 3
A = np.random.rand(batch_size, n, n)
b = np.random.rand(batch_size, n, 1)

# 解决多个方程组
solutions = np.linalg.solve(A, b)

# 沿着第二个维度相加
sum_x = np.sum(solutions, axis=1, keepdims=True)

# 沿着第三个维度展开
sum_x = np.reshape(sum_x, (batch_size, n))

# 输出所有x向量之和
print(sum_x)