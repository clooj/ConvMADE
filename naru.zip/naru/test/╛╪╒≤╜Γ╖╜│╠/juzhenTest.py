import numpy as np

# 构造矩阵A和向量b


A = np.array([[0, 1, 1], [1, 0, 1], [0, 1, 1]])
b = np.array([2, 2, 1])

A1 = np.array([[0, 1, 1], [1, 0, 1]])
b1 = np.array([2, 2])
A2 = np.array([[0, 1, 1], [1, 0, 1]])
b2 = np.array([1, 2])
# 求解线性方程组Ax=b的最小二乘解
for i in range(2000):
    x, residuals, rank, s = np.linalg.lstsq(A, b, rcond=None)
    x1, residuals1 , rank1, s1 = np.linalg.lstsq(A1, b1, rcond=None)

    x2, residuals2 , rank2, s2 = np.linalg.lstsq(A1, b1, rcond=None)

# 计算x1+x2+...+xn
result = np.sum(x)
result1 = np.sum(x1)
result2 = np.sum(x2)
print(result)