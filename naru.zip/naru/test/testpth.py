import torch

file = './resnetrs152_i256_ema-a9aff7f9.pth'
model = torch.load(file)

ss = 0