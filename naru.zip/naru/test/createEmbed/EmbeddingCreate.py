import torch
import torch.nn as nn
a = nn.Embedding(5, 4)
b = nn.Embedding(7, 4)
c = nn.Embedding(9, 4)
a1 = a(torch.tensor([1]))
a2 = a(torch.tensor([2]))
a3 = a(torch.tensor([3]))
b3 = b(torch.tensor([3]))
b4 = b(torch.tensor([4]))
b7 = b(torch.tensor([6]))
c9 = c(torch.tensor([8]))
c3 = c(torch.tensor([3]))
a1