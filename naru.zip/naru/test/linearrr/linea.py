import torch
import torch.nn as nn

# i = nn.Linear(55,55)
# j = nn.Linear(512,100000).to('cuda')
# k = nn.Linear(512,1000000).to('cuda')
iconv = nn.Conv2d(in_channels=1,out_channels=1,kernel_size=3,padding='same')
s = torch.randn([1024,4,55])
q = iconv(s)
q
# e = nn.Embedding(10000000, 512).to('cuda')
# e
