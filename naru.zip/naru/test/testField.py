if True:
    s = 1
print(s)