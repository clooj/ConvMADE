import torch

bs = 6
vocab = 8
num_cols = 11
inp = torch.randint(vocab, (bs, num_cols))
inp