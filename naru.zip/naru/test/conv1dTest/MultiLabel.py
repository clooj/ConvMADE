import torch
import torch.nn as nn
import torch.optim as optim

# 数据准备
x = torch.rand(10, 3) # 此处假设有 10 个样本，每个样本有 3 个特征
y = torch.randint(0, 2, (10, 2)) # 此处假设有 10 个样本，每个样本有 2 个标签，每个标签为 0 或 1

# 定义模型和损失函数
model = nn.Linear(3, 2) # 此处假设模型是一个线性模型
criterion = nn.MultiLabelSoftMarginLoss()

# 定义优化器
optimizer = optim.SGD(model.parameters(), lr=0.1)

# 模型训练
for epoch in range(100):
    optimizer.zero_grad()
    outputs = model(x)
    loss = criterion(outputs, y.float())
    loss.backward()
    optimizer.step()

    if epoch % 10 == 0:
        print("Epoch {} loss:{}".format(epoch, loss.item()))

# 模型预测
with torch.no_grad():
    output = model(x)
    prediction = torch.sigmoid(output) # 根据输出计算预测值
