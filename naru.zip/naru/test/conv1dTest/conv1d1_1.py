import torch
import torch.nn as nn

if __name__ == '__main__':
    conv1 = nn.Conv1d(in_channels=1, out_channels=1, kernel_size=9,padding=4)
    u = nn.GELU()
    input = torch.randn(2048,  55)
    input = input.unsqueeze(1)
    output = conv1(input)
    output = output.squeeze(1)
    outpu = u(output)
    output