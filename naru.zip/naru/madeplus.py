"""MADE and ResMADE."""
import time

import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F


class MaskedLinear(nn.Linear):

    def __init__(self, in_features, out_features, bias=True):
        super().__init__(in_features, out_features, bias)
        self.register_buffer('mask', torch.ones(out_features, in_features))

        self.masked_weight = None

    def set_mask(self, mask):
        """Accepts a mask of shape [in_features, out_features]."""
        self.mask.data.copy_(torch.from_numpy(mask.astype(np.uint8).T))

    def forward(self, input):
        if self.masked_weight is None:
            output = F.linear(input, self.mask * self.weight, self.bias)
            return output
        else:
            # ~17% speedup for Prog Sampling.
            output = F.linear(input, self.masked_weight, self.bias)
            output = output.unsqueeze(1)
            return output


# class ConvBlock(nn.Module):
#     def __init__(self, in_channels:int,
#                  out_channels:int,
#                  groups:int,
#                  kernel_size:int,
#                  activation,
#                  residual=False
#                  ):
#         super().__init__()
#         self.activation = activation
#         self.kernel_size = kernel_size  # 直接给奇数
#         self.padding = kernel_size // 2
#         self.in_channels = in_channels
#         self.out_channels = out_channels
#         self.groups = groups
#         self.residual = residual
#         self.net = []
#         self.net.extend([
#             nn.Conv1d(in_channels=self.in_channels, out_channels=self.out_channels,
#                       kernel_size=self.kernel_size, padding=self.padding, groups=self.groups)
#         ])
#         # resnet 中卷积后面加了normal层和relu层，不过，最后一个relu层是在残差以后加的
#         # TODO 最后的relu层需要pop掉，每层需要加个还需要加个attention层
#         self.net.extend([nn.BatchNorm1d(self.out_channels)])
#         self.net.extend([self.activation])
#         self.net = nn.Sequential(*self.net)
#
#         def forward(self, x):
#             return self.net(x)
class NormalConvBlock(nn.Module):

    def __init__(self, in_channels:int,
                 out_channels:int,
                 groups,
                 kernel_size:int,
                 activation,
                 conv_block_num,
                 residual=True,
                 hasshuffle=False
                 ):
        #feature 是长度而不是卷积核里面的通道数，应该加个输入的长度
        super().__init__()
        self.activation = activation
        self.kernel_size = kernel_size # 直接给奇数
        self.padding = kernel_size // 2
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.groups = groups
        self.residual = residual
        self.conv_block_num = conv_block_num
        self.hasshuffle = hasshuffle
        assert self.in_channels==self.out_channels
        # TODO 这里想要单独弄成个模块
        self.net2 = []
        for i  in range(self.conv_block_num):
            if self.hasshuffle:
                self.net2.extend([
                    Shuffle()
                ])
            self.net2.extend([
                nn.Conv1d(in_channels=self.out_channels, out_channels=self.out_channels,
                          kernel_size=self.kernel_size, padding=self.padding, groups=self.groups)
            ])

            self.net2.extend([nn.BatchNorm1d(self.out_channels)])
            self.net2.extend([self.activation])

        self.net2.pop()
        self.net2 = nn.Sequential(*self.net2)


    def forward(self, x):
        out = x # 这里没有加relu，主要是让其扩张特征数目
        out1 = self.net2(x)

        if(self.residual):
            # 大概率使用残差块
            out2 = out + out1
            out3 = self.activation(out2)
            return out3
        else:
            return self.activation(out1)

class RepConvBlock(nn.Module):
    def __init__(self, in_channels,
                 out_channels,
                 groups,
                 kernel_size,
                 ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.groups = groups
        self.kernel_size = kernel_size
        self.padding = kernel_size // 2
        self.net = []
        self.net.extend([
            nn.Conv1d(in_channels=self.out_channels, out_channels=self.out_channels,
                      kernel_size=self.kernel_size, padding=self.padding, groups=self.groups)
        ])
        self.net = nn.Sequential(*self.net)
        self.net2=[]
        self.net2.extend([
            nn.Conv1d(in_channels=self.out_channels, out_channels=self.out_channels,
                      kernel_size=1, groups=self.groups)
        ])
        self.net2 = nn.Sequential(*self.net2)

    def forward(self,x):
        out1 = self.net(x)
        out2 = self.net2(x)
        return out1 + out2

# 创建可以一次上采样的卷积块
class TransposeConvBlock(nn.Module):

    def __init__(self, in_channels,
                 out_channels,
                 groups,
                 kernel_size,
                 activation,
                 conv_block_num,
                 atten=None,
                 residual=True,
                 hasshuffle=False
                 ):
        #feature 是长度而不是卷积核里面的通道数，应该加个输入的长度
        super().__init__()
        self.activation = activation
        self.kernel_size = kernel_size # 直接给奇数
        self.padding = kernel_size // 2
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.groups = groups
        self.shuffle=hasshuffle
        self.residual = residual
        self.conv_block_num = conv_block_num
        self.atte = atten
        self.net1 = nn.ModuleList()
        #这里只会是两倍，或者相等，不会下降过快。中间我只想让他相等。这里写错了，应该改一下
            # Todo 写错了，需要改一下，特征值的个数的更改和*2 的，和channels数目无关
        # self.net1.extend([
        #     nn.Conv1d(in_channels=self.in_channels, out_channels=self.out_channels,
        #                        kernel_size=self.kernel_size, stride=2, padding=self.padding, groups = self.groups)
        # ])
        #self.conv2 = nn.Conv1d(in_channels=out_features, out_channels=out_features, kernel_size=9,groups=32,padding=4)

        #反卷积，用来扩充特征值 TODO 这里我捉摸着写个单纯的卷积模块 nn.module，方便和resnet这些东西对接
        if self.in_channels == 1:
            # 这里是用在第一个那里，扩充卷积核通道，我是想着卷积核通道数设置一致，都设置成一个数字，最后要改的话再留接口，先写出来。
            self.net1 = nn.ConvTranspose1d(in_channels=self.in_channels, out_channels=self.out_channels,
                                    kernel_size=2, stride=2)

        elif self.out_channels != 1:
            self.net1 = nn.ConvTranspose1d(in_channels=self.in_channels, out_channels=self.out_channels,
                                   kernel_size=2, stride=2, groups=self.groups)
        else:
            self.net1 = nn.Conv1d(in_channels=self.in_channels, out_channels=self.out_channels,
                                           kernel_size=1, stride=1)

        # TODO 这里想要单独弄成个模块
        self.net2 = []
        for i in range(self.conv_block_num):
            # if self.out_channels == 1:
            #     self.net2.extend([
            #         nn.Conv1d(in_channels=self.out_channels, out_channels=self.out_channels,
            #                   kernel_size=self.kernel_size,padding=self.padding)
            #     ])
            # else:
            if self.shuffle:
                self.net2.extend([Shuffle()])
            self.net2.extend([
                nn.Conv1d(in_channels=self.out_channels, out_channels=self.out_channels,
                          kernel_size=self.kernel_size, padding=self.padding,
                          groups=self.groups)
            ])

            # resnet 中卷积后面加了normal层和relu层，不过，最后一个relu层是在残差以后加的
            # TODO 最后的relu层需要pop掉，每层需要加个还需要加个attention层
            self.net2.extend([nn.BatchNorm1d(self.out_channels)])
            self.net2.extend([self.activation])

        #self.net1.extend(activation)
        #self.net1 = nn.Sequential(*self.net1)
        if self.net2 != []:
            self.net2.pop()
        self.net2 = nn.Sequential(*self.net2)


    def forward(self, x):
        # 这里没有加relu，主要是让其扩张特征数目
        if self.net2 != []:
            out = self.net1(x)
            out1 = self.net2(out)

            if self.residual:
                # 大概率使用残差块
                out2 = out + out1
                out3 = self.activation(out2)
                return out3
            else:
                return self.activation(out1)
        else:
            return self.net1(x)

class Unsqueeze(nn.Module):
    def __init__(self,):
        super().__init__()


    def forward(self, x):
        x = x.unsqueeze(1)
        #x = x.squeeze(1)
        return x

class Squeeze(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        x = x.squeeze(1)
        return x

class Shuffle(nn.Module):
    def __init__(self):
        super().__init__()

    # 只是这个模块的东西
    def forward(self, x):
        idx = torch.randperm(x.shape[1])
        x = x[: , idx].view(x.size())
        return x

class ConvMADE(nn.Module):

    def __init__(
            self,
            nin,
            hidden_sizes,
            nout,
            num_masks=1,
            natural_ordering=True,
            input_bins=None,
            activation=nn.ReLU,
            batchsize=20,
            hasfc=False,
            hasshuffle=False,
            do_direct_io_connections=False,
            input_encoding=None,
            output_encoding='one_hot',
            convblocknum=1,
            embed_size=32,
            input_no_emb_if_leq=True,
            residual_connections=True,
            column_masking=False,
            seed=11123,
            fixed_ordering=None,
            kernel_size=9,
            kernel_group=32,
            channels=256
    ):

        super().__init__()
        print('fixed_ordering', fixed_ordering, 'seed', seed,
              'natural_ordering', natural_ordering)
        self.nin = nin
        self.kernel_group = kernel_group
        assert input_encoding in [None, 'one_hot', 'binary', 'embed']
        self.input_encoding = input_encoding
        assert output_encoding in ['one_hot', 'embed']
        self.embed_size = self.emb_dim = embed_size
        self.output_encoding = output_encoding
        self.activation = activation(inplace=True)
        self.kernel_size = kernel_size
        self.nout = nout
        self.batchsize=batchsize
        self.hidden_sizes = hidden_sizes
        self.input_bins = input_bins
        self.input_no_emb_if_leq = input_no_emb_if_leq
        # self.do_direct_io_connections = do_direct_io_connections
        self.column_masking = column_masking
        self.residual_connections = residual_connections
        self.channels = channels
        self.fixed_ordering = fixed_ordering
        self.convblocknum = convblocknum
        self.hasfc=hasfc
        self.hasshuffle=hasshuffle
        # self.times =
        if fixed_ordering is not None:
            assert num_masks == 1
            print('** Fixed ordering {} supplied, ignoring natural_ordering'.
                  format(fixed_ordering))

        assert self.input_bins
        self.encoded_bins = list(
            map(self._get_output_encoded_dist_size, self.input_bins))
        self.input_bins_encoded = list(
            map(self._get_input_encoded_dist_size, self.input_bins))
        self.input_bins_encoded_cumsum = np.cumsum(
            list(map(self._get_input_encoded_dist_size, self.input_bins)))
        print('encoded_bins (output)', self.encoded_bins)
        print('encoded_bins (input)', self.input_bins_encoded)

        hs = [nin] + hidden_sizes + [sum(self.encoded_bins)]
        self.out = sum(self.encoded_bins)
        self.input_size = 0
        for i, dist_size in enumerate(self.input_bins):
            self.input_size += self._get_input_encoded_dist_size(dist_size)
        import math
        #这里计划弄两个方式，一个方式是直接nin * 2, 扩增到nout附近，一个是如下，弄成2的n次幂附近
        # self.firstlayer = 2 ** math.ceil(math.log2(input_size))
        # self.lastlayer = 2 ** math.floor(math.log2(output_size))
        # self.lastlayer1 = 2 ** math.ceil(math.log2(output_size))
        print(self.out)
        print(self.input_size)
        self.modeloutput = self.input_size
        if self.out // self.input_size <= 8:
            # 给个小保底
            self.deconvlayers = 1
            self.convlayers=7
        else:
            # 这里是因为卷积中的stride=2,
            # TODO 这里应该有个判断，如果最后面不加fc那么，应该是ceil，反之，则是floor
            # TODO 结果就是layer最好不要太大，不然会膨胀到非常难以接受的地步，所以决定最大弄成五次，其余多出来的弄成普通卷积层。
            self.deconvlayers = 3
            self.convlayers = math.ceil(math.log2(self.out//self.input_size)) - 5
        # TODO net这里不要变，有后续的东西不好改 ,还有就是下面的卷积个数先放着，不好自定义生成。看后续再手动
        # for i in range(self.layers):

        self.net =[]
        self.net.extend([MaskedLinear(self.input_size, self.input_size, bias=True),
                         self.activation])
        self.net.extend([MaskedLinear(self.input_size, self.input_size, bias=True),
                         self.activation])
        self.net.extend([Unsqueeze()])
        self.net.extend([TransposeConvBlock(1, self.channels, activation=self.activation,
                                            kernel_size=self.kernel_size,
                                            conv_block_num=self.convblocknum, groups=self.kernel_group,
                                            residual=self.residual_connections,
                                            hasshuffle=self.hasshuffle)])
        self.modeloutput = self.modeloutput * 2
        # 这里的channels我想改成512,不用再两个卷积中更改通道数。先看看再说,512 过于离谱，
        # 用了256，不过想起来图片224*224*3，通道数才96多，估摸着96或者64应该够了，傻逼实验室，没有一点实验机器
        # self.transconv1 =
        for i in range(self.deconvlayers-1):
            self.net.extend([
                TransposeConvBlock(
                    self.channels, self.channels, activation=self.activation,
                    kernel_size=self.kernel_size, groups=self.kernel_group,
                    conv_block_num=self.convblocknum,
                    residual=self.residual_connections,
                    hasshuffle=self.hasshuffle)
            ])
            self.modeloutput = self.modeloutput * 2
        for i in range(self.convlayers):
            self.net.extend([
                NormalConvBlock(
                    self.channels, self.channels, activation=self.activation,
                    kernel_size=self.kernel_size, groups=self.kernel_group,
                    conv_block_num=self.convblocknum,
                    residual=self.residual_connections)
            ])
        self.net.extend([TransposeConvBlock(self.channels, 1, activation=self.activation,
                                            kernel_size=self.kernel_size,
                                            groups=self.kernel_group, conv_block_num=0,
                                            residual=self.residual_connections)])
        self.modeloutput = self.modeloutput
        self.net.extend([Squeeze()])
        self.net.extend([MaskedLinear(self.modeloutput,self.out,True),
                         self.activation])
        self.net = nn.Sequential(*self.net)
        # TODO encode 格式可能要删减
        # if self.input_encoding is not None:
        #     # Input layer should be changed.
        #     assert self.input_bins is not None
        #     input_size = 0
        #     for i, dist_size in enumerate(self.input_bins):
        #         input_size += self._get_input_encoded_dist_size(dist_size)
            # 第一层先来一个全连接层，这样可以方便卷积快速获得全局视野，不用小卷积很长时间能获得大视野。
            #先用着，感觉也没啥必要，先去掉
            # new_layer0 = TransposeConvBlock(1, self.net[0].out_features)
            # self.net[0] = new_layer0

        if self.output_encoding == 'embed':
            assert self.input_encoding == 'embed'

        if self.input_encoding == 'embed':
            self.embeddings = nn.ModuleList()
            for i, dist_size in enumerate(self.input_bins):
                if dist_size <= self.embed_size and self.input_no_emb_if_leq:
                    embed = None
                else:
                    embed = nn.Embedding(dist_size, self.embed_size)
                self.embeddings.append(embed)

        # Learnable [MASK] representation ，这里是对输入数据的一次处理，先放着。
        if self.column_masking:
            self.unk_embeddings = nn.ParameterList()
            for i, dist_size in enumerate(self.input_bins):
                self.unk_embeddings.append(
                    nn.Parameter(torch.zeros(1, self.input_bins_encoded[i])))

        self.natural_ordering = natural_ordering
        self.num_masks = num_masks
        self.seed = seed if seed is not None else 11123
        self.init_seed = self.seed

        self.direct_io_layer = None
        self.logit_indices = np.cumsum(self.encoded_bins)
        self.m = {}

        self.update_masks()
        self.orderings = [self.m[-1]]

        # Optimization: cache some values needed in EncodeInput().
        self.bin_as_onehot_shifts = None

    def _get_input_encoded_dist_size(self, dist_size):
        if self.input_encoding == 'embed':
            if self.input_no_emb_if_leq:
                dist_size = min(dist_size, self.embed_size)
            else:
                dist_size = self.embed_size
        elif self.input_encoding == 'one_hot':
            pass
        elif self.input_encoding == 'binary':
            dist_size = max(1, int(np.ceil(np.log2(dist_size))))
        elif self.input_encoding is None:
            return 1
        else:
            assert False, self.input_encoding
        return dist_size

    def _get_output_encoded_dist_size(self, dist_size):
        if self.output_encoding == 'embed':
            if self.input_no_emb_if_leq:
                dist_size = min(dist_size, self.embed_size)
            else:
                dist_size = self.embed_size
        elif self.output_encoding == 'one_hot':
            pass
        elif self.output_encoding == 'binary':
            dist_size = max(1, int(np.ceil(np.log2(dist_size))))
        return dist_size

    def update_masks(self, invoke_order=None):
        """Update m() for all layers and change masks correspondingly.

        No-op if "self.num_masks" is 1.
        """
        if self.m and self.num_masks == 1:
            return
        L = len(self.hidden_sizes)

        ### Precedence of several params determining ordering:
        #
        # invoke_order
        # orderings
        # fixed_ordering
        # natural_ordering
        #
        # from high precedence to low.

        if invoke_order is not None:
            found = False
            for i in range(len(self.orderings)):
                if np.array_equal(self.orderings[i], invoke_order):
                    found = True
                    break
            assert found, 'specified={}, avail={}'.format(
                self.orderings[i], self.orderings)  # 这里原来是弄了个错误，是ordering，
                                                    # 我猜测是想把特殊的那个给弄出来，所以改了改。不过只是个单纯的判断，不影响使用
            # orderings = [ o0, o1, o2, ... ]
            # seeds = [ init_seed, init_seed+1, init_seed+2, ... ]
            rng = np.random.RandomState(self.init_seed + i)
            self.seed = (self.init_seed + i + 1) % self.num_masks
            self.m[-1] = invoke_order
        elif hasattr(self, 'orderings'):
            # Cycle through the special orderings.
            rng = np.random.RandomState(self.seed)
            self.seed = (self.seed + 1) % self.num_masks
            self.m[-1] = self.orderings[self.seed % 4]
        else:
            rng = np.random.RandomState(self.seed)
            self.seed = (self.seed + 1) % self.num_masks
            self.m[-1] = np.arange(
                self.nin) if self.natural_ordering else rng.permutation(
                    self.nin)
            if self.fixed_ordering is not None:
                self.m[-1] = np.asarray(self.fixed_ordering)

        if self.nin > 1:
            for l in range(L):
                if self.residual_connections:
                    # Sequential assignment for ResMade: https://arxiv.org/pdf/1904.05626.pdf
                    self.m[l] = np.array([(k - 1) % (self.nin - 1)
                                          for k in range(self.hidden_sizes[l])])
                else:
                    # Samples from [0, ncols - 1).
                    self.m[l] = rng.randint(self.m[l - 1].min(),
                                            self.nin - 1,
                                            size=self.hidden_sizes[l])
        else:
            # This should result in first layer's masks == 0.
            # So output units are disconnected to any inputs.
            for l in range(L):
                self.m[l] = np.asarray([-1] * self.hidden_sizes[l])

        masks = [self.m[l - 1][:, None] <= self.m[l][None, :] for l in range(L)]
        masks.append(self.m[L - 1][:, None] < self.m[-1][None, :])

        if self.nout > self.nin:
            # Last layer's mask needs to be changed.

            if self.input_bins is None:
                k = int(self.nout / self.nin)
                # Replicate the mask across the other outputs
                # so [x1, x2, ..., xn], ..., [x1, x2, ..., xn].
                masks[-1] = np.concatenate([masks[-1]] * k, axis=1)
            else:
                # [x1, ..., x1], ..., [xn, ..., xn] where the i-th list has
                # input_bins[i - 1] many elements (multiplicity, # of classes).
                mask = np.asarray([])
                for k in range(masks[-1].shape[0]):
                    tmp_mask = []
                    for idx, x in enumerate(zip(masks[-1][k], self.input_bins)):
                        mval, nbins = x[0], self._get_output_encoded_dist_size(
                            x[1])
                        tmp_mask.extend([mval] * nbins)
                    tmp_mask = np.asarray(tmp_mask)
                    if k == 0:
                        mask = tmp_mask
                    else:
                        mask = np.vstack([mask, tmp_mask])
                masks[-1] = mask

        if self.input_encoding is not None:
            # Input layer's mask should be changed.

            assert self.input_bins is not None
            # [nin, hidden].
            mask0 = masks[0]
            new_mask0 = []
            for i, dist_size in enumerate(self.input_bins):
                dist_size = self._get_input_encoded_dist_size(dist_size)
                # [dist size, hidden]
                new_mask0.append(
                    np.concatenate([mask0[i].reshape(1, -1)] * dist_size,
                                   axis=0))
            # [sum(dist size), hidden]
            new_mask0 = np.vstack(new_mask0)
            masks[0] = new_mask0

        # layers = [
        #     l for l in self.net if isinstance(l, MaskedLinear) or
        #     isinstance(l, MaskedLinear)
        # ]
        # assert len(layers) == len(masks), (len(layers), len(masks))
        # for l, m in zip(layers, masks):
        #     l.set_mask(m)

        # if self.do_direct_io_connections:
        #     self._build_or_update_direct_io()

    def name(self):
        n = 'convmade'
        # if self.residual_connections:
        #     n += '-residual'
        n += '-batchsize' +str(self.batchsize)
        n += '-emb' + str(self.embed_size)
        n += '-channels' + str(self.channels)
        n += '-kernelsize' + str(self.kernel_size)
        n += '-kernelgroup' + str(self.kernel_group)
        n += '-convnum' + str(self.convblocknum)
        if self.residual_connections == True:
            n += '-residual'
        if self.hasshuffle == True:
            n += '-shuffle'
        if self.num_masks > 1:
            n += '-{}masks'.format(self.num_masks)
        if not self.natural_ordering:
            n += '-nonNatural'
        # n += ('-no' if not self.do_direct_io_connections else '-') + 'directIo'
        n += '-{}In{}Out'.format(self.input_encoding, self.output_encoding)
        if self.input_no_emb_if_leq:
            n += '-inputNoEmbIfLeq'
        if self.column_masking:
            n += '-colmask'
        n += str(time.time())
        return n

    def Embed(self, data, natural_col=None, out=None):
        if data is None:
            if out is None:
                return self.unk_embeddings[natural_col]
            out.copy_(self.unk_embeddings[natural_col])
            return out

        bs = data.size()[0]
        y_embed = []
        data = data.long()

        if natural_col is not None:
            # Fast path only for inference.  One col.

            coli_dom_size = self.input_bins[natural_col]
            # Embed?
            if coli_dom_size >= self.embed_size or not self.input_no_emb_if_leq:
                res = self.embeddings[natural_col](data.view(-1,))
                if out is not None:
                    out.copy_(res)
                    return out
                return res
            else:
                if out is None:
                    out = torch.zeros(bs, coli_dom_size, device=data.device)

                out.scatter_(1, data, 1)
                return out
        else:
            for i, coli_dom_size in enumerate(self.input_bins):
                # Wildcard column? use -1 as special token.
                # Inference pass only (see estimators.py).
                skip = data[0][i] < 0

                # Embed?
                if coli_dom_size >= self.embed_size or not self.input_no_emb_if_leq:
                    col_i_embs = self.embeddings[i](data[:, i])
                    if not self.column_masking:
                        y_embed.append(col_i_embs)
                    else:
                        dropped_repr = self.unk_embeddings[i]

                        def dropout_p():
                            return np.random.randint(0, self.nin) / self.nin

                        # During training, non-dropped 1's are scaled by
                        # 1/(1-p), so we clamp back to 1.
                        batch_mask = torch.clamp(
                            torch.dropout(torch.ones(bs, 1, device=data.device),
                                          p=dropout_p(),
                                          train=self.training), 0, 1)
                        y_embed.append(batch_mask * col_i_embs +
                                       (1. - batch_mask) * dropped_repr)
                else:
                    if skip:
                        y_embed.append(self.unk_embeddings[i])
                        continue
                    y_onehot = torch.zeros(bs,
                                           coli_dom_size,
                                           device=data.device)
                    y_onehot.scatter_(1, data[:, i].view(-1, 1), 1)
                    if self.column_masking:

                        def dropout_p():
                            return np.random.randint(0, self.nin) / self.nin

                        # During training, non-dropped 1's are scaled by
                        # 1/(1-p), so we clamp back to 1.
                        batch_mask = torch.clamp(
                            torch.dropout(torch.ones(bs, 1, device=data.device),
                                          p=dropout_p(),
                                          train=self.training), 0, 1)
                        y_embed.append(batch_mask * y_onehot +
                                       (1. - batch_mask) *
                                       self.unk_embeddings[i])
                    else:
                        y_embed.append(y_onehot)
            return torch.cat(y_embed, 1)

    def ToOneHot(self, data):
        assert not self.column_masking, 'not implemented'
        bs = data.size()[0]
        y_onehots = []
        data = data.long()
        for i, coli_dom_size in enumerate(self.input_bins):
            if coli_dom_size <= 2:
                y_onehots.append(data[:, i].view(-1, 1).float())
            else:
                y_onehot = torch.zeros(bs, coli_dom_size, device=data.device)
                y_onehot.scatter_(1, data[:, i].view(-1, 1), 1)
                y_onehots.append(y_onehot)

        # [bs, sum(dist size)]
        return torch.cat(y_onehots, 1)

    def ToBinaryAsOneHot(self, data, threshold=0, natural_col=None, out=None):
        if data is None:
            if out is None:
                return self.unk_embeddings[natural_col]
            out.copy_(self.unk_embeddings[natural_col])
            return out

        bs = data.size()[0]
        data = data.long()
        if self.bin_as_onehot_shifts is None:
            # This caching gives very sizable gains.
            self.bin_as_onehot_shifts = [None] * self.nin
            const_one = torch.ones([], dtype=torch.long, device=data.device)
            for i, coli_dom_size in enumerate(self.input_bins):
                # Max with 1 to guard against cols with 1 distinct val.
                one_hot_dims = max(1, int(np.ceil(np.log2(coli_dom_size))))
                self.bin_as_onehot_shifts[i] = const_one << torch.arange(
                    one_hot_dims, device=data.device)

        if natural_col is None:
            # Train path.

            assert out is None
            y_onehots = [None] * self.nin
            for i, coli_dom_size in enumerate(self.input_bins):
                if coli_dom_size > threshold:
                    # Bit shift in PyTorch + GPU is 27% faster than np.
                    data_np = data.narrow(1, i, 1)
                    binaries = (data_np & self.bin_as_onehot_shifts[i]) > 0
                    y_onehots[i] = binaries

                    if self.column_masking:
                        dropped_repr = self.unk_embeddings[i]

                        def dropout_p():
                            return np.random.randint(0, self.nin) / self.nin

                        # During training, non-dropped 1's are scaled by
                        # 1/(1-p), so we clamp back to 1.
                        batch_mask = torch.clamp(
                            torch.dropout(torch.ones(bs, 1, device=data.device),
                                          p=dropout_p(),
                                          train=self.training), 0, 1)
                        binaries = binaries.to(torch.float32,
                                               non_blocking=True,
                                               copy=False)
                        y_onehots[i] = batch_mask * binaries + (
                            1. - batch_mask) * dropped_repr

                else:
                    # Encode as plain one-hot.
                    y_onehot = torch.zeros(bs,
                                           coli_dom_size,
                                           device=data.device)
                    y_onehot.scatter_(1, data[:, i].view(-1, 1), 1)
                    y_onehots[i] = y_onehot

            res = torch.cat(y_onehots, 1)
            return res.to(torch.float32, non_blocking=True, copy=False)

        else:
            # Inference path.
            natural_idx = natural_col
            coli_dom_size = self.input_bins[natural_idx]
            if coli_dom_size > threshold:
                # Bit shift in PyTorch + GPU is 27% faster than np.
                data_np = data
                if out is None:
                    res = (data_np & self.bin_as_onehot_shifts[natural_idx]) > 0
                    return res.to(torch.float32, non_blocking=True, copy=False)
                else:
                    out.copy_(
                        (data_np & self.bin_as_onehot_shifts[natural_idx]) > 0)
                    return out
            else:
                assert False, 'inference'
                if out is None:
                    y_onehot = torch.zeros(bs,
                                           coli_dom_size,
                                           device=data.device)
                    y_onehot.scatter_(1, data, 1)
                    res = y_onehot
                    return res.to(torch.float32, non_blocking=True, copy=False)

                out.scatter_(1, data, 1)
                return out

    def EncodeInput(self, data, natural_col=None, out=None):
        """"Warning: this could take up a significant portion of a forward pass.

        Args:
          natural_col: if specified, 'data' has shape [N, 1] corresponding to
              col-'natural-col'.  Otherwise 'data' corresponds to all cols.
          out: if specified, assign results into this Tensor storage.
        """
        if self.input_encoding == 'binary':
            return self.ToBinaryAsOneHot(data, natural_col=natural_col, out=out)
        elif self.input_encoding == 'embed':
            return self.Embed(data, natural_col=natural_col, out=out)
        elif self.input_encoding is None:
            return data
        elif self.input_encoding == 'one_hot':
            return self.ToOneHot(data)
        else:
            assert False, self.input_encoding

    def forward(self, x):
        """Calculates unnormalized logits.

        If self.input_bins is not specified, the output units are ordered as:
            [x1, x2, ..., xn], ..., [x1, x2, ..., xn].
        So they can be reshaped as thus and passed to a cross entropy loss:
            out.view(-1, model.nout // model.nin, model.nin)

        Otherwise, they are ordered as:
            [x1, ..., x1], ..., [xn, ..., xn]
        And they can't be reshaped directly.

        Args:
          x: [bs, ncols].
        """
        x = self.EncodeInput(x)
        # 这里residual进入conv块里面了。
        # if self.direct_io_layer is not None:
        #     residual = self.direct_io_layer(x)
        #     return self.net(x) + residual

        return self.net(x)

    def forward_with_encoded_input(self, x):
        # 同样残差块给弄没了
        # if self.direct_io_layer is not None:
        #     residual = self.direct_io_layer(x)
        #     return self.net(x) + residual
        # TODO net还需要改东西
        return self.net(x)

    def logits_for_col(self, idx, logits):
        """Returns the logits (vector) corresponding to log p(x_i | x_(<i)).

        Args:
          idx: int, in natural (table) ordering.
          logits: [batch size, hidden] where hidden can either be sum(dom
            sizes), or emb_dims.

        Returns:
          logits_for_col: [batch size, domain size for column idx].
        """
        assert self.input_bins is not None

        if idx == 0:
            logits_for_var = logits[:, :self.logit_indices[0]]
        else:
            logits_for_var = logits[:, self.logit_indices[idx - 1]:self.
                                    logit_indices[idx]]
        if self.output_encoding != 'embed':
            return logits_for_var

        embed = self.embeddings[idx]

        if embed is None:
            # Can be None for small-domain columns.
            return logits_for_var

        # Otherwise, dot with embedding matrix to get the true logits.
        # [bs, emb] * [emb, dom size for idx]
        return torch.matmul(logits_for_var, embed.weight.t())


    def nll(self, logits, data):
        """Calculates -log p(data), given logits (the conditionals).

        Args:
          logits: [batch size, hidden] where hidden can either be sum(dom
            sizes), or emb_dims.
          data: [batch size, nin].

        Returns:
          nll: [batch size].
        """
        if data.dtype != torch.long:
            data = data.long()
        nll = torch.zeros(logits.size()[0], device=logits.device)
        for i in range(self.nin):
            logits_i = self.logits_for_col(i, logits)
            # self.output_encoding
            nll += F.cross_entropy(logits_i, data[:, i], reduction='none')

        return nll

    def sample(self, num=1, device=None):
        assert self.natural_ordering
        assert self.input_bins and self.nout > self.nin
        with torch.no_grad():
            sampled = torch.zeros((num, self.nin), device=device)
            indices = np.cumsum(self.input_bins)
            for i in range(self.nin):
                logits = self.forward(sampled)
                s = torch.multinomial(
                    torch.softmax(self.logits_for_i(i, logits), -1), 1)
                sampled[:, i] = s.view(-1,)
        return sampled


if __name__ == '__main__':
    # Checks for the autoregressive property.
    rng = np.random.RandomState(14)
    # (nin, hiddens, nout, input_bins, direct_io)
    configs_with_input_bins = [
        (2, [10], 2 + 5, [2, 5], False),
        (2, [10, 30], 2 + 5, [2, 5], False),
        (3, [6], 2 + 2 + 2, [2, 2, 2], False),
        (3, [4, 4], 2 + 1 + 2, [2, 1, 2], False),
        (4, [16, 8, 16], 2 + 3 + 1 + 2, [2, 3, 1, 2], False),
        (2, [10], 2 + 5, [2, 5], True),
        (2, [10, 30], 2 + 5, [2, 5], True),
        (3, [6], 2 + 2 + 2, [2, 2, 2], True),
        (3, [4, 4], 2 + 1 + 2, [2, 1, 2], True),
        (4, [16, 8, 16], 2 + 3 + 1 + 2, [2, 3, 1, 2], True),
    ]
    for nin, hiddens, nout, input_bins, direct_io in configs_with_input_bins:
        print(nin, hiddens, nout, input_bins, direct_io, '...', end='')
        model = ConvMADE(nin,
                     hiddens,
                     nout,
                     input_bins=input_bins,
                     natural_ordering=True,
                     do_direct_io_connections=direct_io)
        model.eval()
        print(model)
        for k in range(nout):
            inp = torch.tensor(rng.rand(1, nin).astype(np.float32),
                               requires_grad=True)
            loss = model(inp)
            l = loss[0, k]
            l.backward()
            depends = (inp.grad[0].numpy() != 0).astype(np.uint8)

            depends_ix = np.where(depends)[0].astype(np.int32)
            var_idx = np.argmax(k < np.cumsum(input_bins))
            prev_idxs = np.arange(var_idx).astype(np.int32)

            # Asserts that k depends only on < var_idx.
            print('depends', depends_ix, 'prev_idxs', prev_idxs)
            assert len(torch.nonzero(inp.grad[0, var_idx:])) == 0
        print('ok')
    print('[MADE] Passes autoregressive-ness check!')
