"""Dataset registrations."""
import csv
import os

import numpy as np
import pandas as pd

import common


def LoadDmv(filename='Vehicle__Snowmobile__and_Boat_Registrations.csv'):
    # csv_file = 'C:/Users/ren/PycharmProjects/naru/datasets/{}'.format(filename)
    cols = [
        'Record Type', 'Registration Class', 'State', 'County', 'Body Type',
        'Fuel Type', 'Reg Valid Date', 'Color', 'Scofflaw Indicator',
        'Suspension Indicator', 'Revocation Indicator'
    ]
    type_casts = {'Reg Valid Date': np.datetime64}
    return loadDataSet(file=filename,filealias='DMV',cols=cols,type_casts=type_casts)
    # return common.CsvTable('DMV', csv_file, cols, type_casts)


def loadNoheaderDataSet(filepath, filename):
    csv_file = filepath
    return common.CsvTable(name=filename, cols= None, filename_or_df=csv_file,sep=",", header=None)

# 加载数据，csv数据转成Table
def loadDataSet(file,
                filealias,
                type_casts=None,
                cols=None,
                csv_file='C:/Users/ren/PycharmProjects/naru/datasets/{}'):
    csv_file = csv_file.format(file)
    if cols is None:
        with open(csv_file, 'r') as fr:
            cols = csv.DictReader(fr).fieldnames
    return common.CsvTable(name=filealias, cols=cols, filename_or_df=csv_file,sep=",", type_casts=type_casts)


def loadDMVSim(filename='Vehiclebak.csv'):
    return loadDataSet(file=filename)
if __name__ == '__main__':
    # file = loadDataSet('Vehicle__Snowmobile__and_Boat_Registrations.csv','dmvall')
    csv_file = 'C:/Users/ren/PycharmProjects/naru/datasets/{}'.format('Vehiclebak.csv')
    # df = pd.read_csv(csv_file)
    # cols = df.columns.tolist()
    with open(csv_file, 'r') as fr:
        cols = csv.DictReader(fr).fieldnames
    type_casts = {'Reg Valid Date': np.datetime64}
    # cols = ['Unladen Weight']
    # df = pd.read_csv(csv_file)
    # df['Unladen Weight'] = pd.to_numeric(df['Unladen Weight'], errors='coerce').fillna(0).astype(int)
    # # p = set(df['Unladen Weight'])
    # df.to_csv('Vehiclebak.csv',index=False)

    file = loadDataSet(file='Vehiclebak.csv', filealias='dmvall',type_casts=type_casts)
    file