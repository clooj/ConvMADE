import pandas as pd
import numpy as np
import time


def ErrorMetric(est_card, card):
    if card == 0 and est_card != 0:
        return est_card
    if card != 0 and est_card == 0:
        return card
    if card == 0 and est_card == 0:
        return 1.0
    return max(est_card / card, card / est_card)

class Postgres():

    def __init__(self, database="imdb",
                 table_names=['cast_info', 'movie_companies', 'movie_info', 'movie_keyword', 'title','movie_info_idx'],
                 port=5432):
        import psycopg2

        super(Postgres, self).__init__()
        self.query_starts = []
        self.query_dur_ms = []
        self.errs = []
        self.est_cards = []
        self.true_cards = []
        self.average = None

        self.conn = psycopg2.connect(user="postgres", password="postgres", database=database, port=port)
        self.conn.autocommit = True
        self.cursor = self.conn.cursor()
        self.name = 'Postgres'

        for relation in table_names:
            self.cursor.execute('analyze ' + relation + ';')
            self.conn.commit()
        self.table_names = table_names

        self.database = database



    def execute(self):
        sql = 'job-light-ranges-nocount.sql'
        sql = open(sql,'r',encoding = 'utf8')
        a = 'btrue.txt'
        a = open(a, 'r', encoding='utf8')

        for i in range(1000):
            query =  sql.readline()
            sqltext = "explain(format json) " +query
            self.OnStart()
            self.cursor.execute(sqltext)
            res = self.cursor.fetchall()
            result = res[0][0][0]['Plan']['Plan Rows']
            self.OnEnd()
            u = a.readline()
            truecard = int(u)
            self.errs.append(ErrorMetric(truecard,result))
        print(self.errs, 'max', np.max(self.errs), '99th',
              np.quantile(self.errs, 0.99), '95th', np.quantile(self.errs, 0.95),
              'median', np.quantile(self.errs, 0.5),'average',np.average(self.errs))



    def OnStart(self):
        self.query_starts.append(time.time())

    def OnEnd(self):
        self.query_dur_ms.append((time.time() - self.query_starts[-1]) * 1e3)

    def AddError(self, err):
        self.errs.append(err)

    def AddError(self, err, est_card, true_card):
        self.errs.append(err)
        self.est_cards.append(est_card)
        self.true_cards.append(true_card)

    def __str__(self):
        return self.name

    def get_stats(self):
        return [
            self.query_starts, self.query_dur_ms, self.errs, self.est_cards,
            self.true_cards
        ]

    def merge_stats(self, state):
        self.query_starts.extend(state[0])
        self.query_dur_ms.extend(state[1])
        self.errs.extend(state[2])
        self.est_cards.extend(state[3])
        self.true_cards.extend(state[4])

    def report(self):
        est = self
        if est.name == 'CardEst':
            est.name = str(est)
        print(est.name, "max", np.max(est.errs), "99th",
              np.quantile(est.errs, 0.99), "95th", np.quantile(est.errs, 0.95),
              "median", np.quantile(est.errs, 0.5), "average", np.average(est.errs), "time_ms",
              np.mean(est.query_dur_ms))

a = Postgres()
a.execute()
# a = 'btrue.txt'
# a = open(a,'r',encoding = 'utf8')
# u = a.readline()
# u = int(u)
# u