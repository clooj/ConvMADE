uild #!/bin/bash

RUSTLIB=librustlib.dll
PYLIB=rustlib.dll
SCRIPT_DIR=`dirname "$0"`
LIB_DIR=$SCRIPT_DIR/target/release
INSTALL_DIR=$SCRIPT_DIR/..

cargo +nightly build --release || exit $?
cp "$LIB_DIR/$RUSTLIB" "$INSTALL_DIR/$PYLIB" || exit $?
echo "Installed $INSTALL_DIR/$PYLIB"
