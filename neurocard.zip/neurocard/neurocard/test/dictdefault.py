from collections import defaultdict

dic = defaultdict(int)
dic['a'] = 1
dic['b'] = 2

dic