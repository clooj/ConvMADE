arr = []


def runninsum(arr):
    srr = []
    temp = 0
    summ = 0
    for i in arr:
        temp = i
        summ = summ + temp
        srr.append(summ)

    return srr


n = int(input("enter the number of elements:"))
for j in range(0, n):
    ele = int(input())
    arr.append(ele)
print(arr)

num = runninsum(arr)
print(num)