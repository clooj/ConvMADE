import torch
import torch.nn as nn
a = nn.Embedding(10, 5)
b = []
test = torch.LongTensor([1])

for i in range(100):
    s = []
    s.append(i)
    s = torch.Tensor(s)
    s = s.long()
    b.append(s)


print(b[0])
for j in range(10):
    print(a(b[j]))
ss