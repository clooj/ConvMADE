import ray
ss = ["sss"]
print(ray.get(ss))
