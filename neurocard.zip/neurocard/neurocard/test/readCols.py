import pandas as pd
filename = r'../datasets/job/cast_info.csv'
cols = ['movie_id', 'role_id']
df = pd.read_csv(filename, usecols=cols)#, **kwargs)
if cols is not None:
    # Use [cols] here anyway to reorder columns by 'cols'.
    df = df[cols]